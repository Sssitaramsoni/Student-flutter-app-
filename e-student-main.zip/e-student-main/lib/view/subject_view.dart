import 'package:flutter/material.dart';

class SubjectView extends StatefulWidget {
  const SubjectView({Key key}) : super(key: key);

  @override
  _SubjectViewState createState() => _SubjectViewState();
}

class _SubjectViewState extends State<SubjectView> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
