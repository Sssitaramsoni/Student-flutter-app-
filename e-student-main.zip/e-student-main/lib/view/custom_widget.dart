
import 'dart:ffi';

import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

Widget CustomDivider({double height=1,Color color=Colors.grey,EdgeInsetsGeometry margin = EdgeInsets.zero}){
  return Container(
    width: double.infinity,
    height: height,
    color: color,
    margin: margin,
  );
}

Widget ResponsiveContainer({@required BuildContext context,@required Widget child,EdgeInsetsGeometry padding=EdgeInsets.zero,BoxDecoration decoration}){
  bool isTab=MediaQuery.of(context).size.width>=600;
  return Container(
    width: double.infinity,
    padding: padding,
    alignment: Alignment.topCenter,
    margin: EdgeInsets.symmetric(
      horizontal: isTab?120:0,
    ),
    decoration: decoration,
    child: child,
  );
}

Widget HeaderView({@required String label}){
  return Container(
    width: double.infinity,
    padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 10),
    alignment: Alignment.center,
    margin: EdgeInsets.zero,
    decoration:BoxDecoration(color: primaryColor),
    child: semiBoldText(label,size: 14,color: Colors.white),
  );
}

Widget BadgeView({@required Widget child,dynamic value=0,VoidCallback onClick}){
  return Container(
    alignment: Alignment.center,
    margin: EdgeInsets.symmetric(horizontal: 10),
    child:GestureDetector(
      onTap: onClick,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          child,
          if(value!=0)
            Positioned(
              top: -2,
              right: -2,
              child: CircleAvatar(
                backgroundColor: Colors.red,
                maxRadius: 8,
                child: boldText(value.toString(),color: Colors.white,size: 8),
              ),
            )
        ],
      ),
    ),
  );
}

Widget SearchView({@required TextEditingController controller,FocusNode focusNode,Function onChange,VoidCallback onClear}){
  return Container(
    height: 50,
    margin: const EdgeInsets.all(10),
    decoration: BoxDecoration(
      color: primaryColor.withOpacity(0.1),
      borderRadius: BorderRadius.circular(24)
    ),
    child: TextField(
      focusNode: focusNode,
      controller: controller,
      minLines: 1,
      maxLines: 1,
      textInputAction: TextInputAction.done,
      keyboardType: TextInputType.text,
      style: GoogleFonts.lato(
        color: primaryColor,
        fontSize: 14,
      ),
      decoration: InputDecoration(
        border: InputBorder.none,
        contentPadding: const EdgeInsets.symmetric(horizontal: 20,vertical: 8),
        hintText: 'Search here...',
        hintStyle: GoogleFonts.lato(
          color: Colors.grey,
          fontSize: 14,
        ),
        suffixIcon:Container(
          width: 30,
          height: 44,
          child: InkWell(
            onTap: onClear,
            child: Icon(Icons.clear,color: primaryColor,),
          ),
        )
      ),
      onChanged: onChange,
    ),
  );
}

Widget AppCheckBox({String label = 'Label',@required bool value,@required Function(bool chnaged) onChanged}){
  return InkWell(
    onTap: ()=>onChanged(!value),
    child: Row(
      children: [
        Container(
          child: value?_check():_uncheck(),
        ),
        const SizedBox(width: 10,),
        regularText(label,size: 14,)
      ],
    ),
  );
}

Widget ClosePopupWidget(){
  return Center(
    child: Container(
      width: 60,
      height: 6,
      margin: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: primaryColor.withOpacity(0.2),
        borderRadius: BorderRadius.circular(6)
      ),
    ),
  );
}

///private method
///
Widget _check(){
  return Container(
    width: 20,
    height: 20,
    decoration: BoxDecoration(
      color:primaryColor,
      borderRadius: BorderRadius.circular(4)
    ),
    alignment: Alignment.center,
    child: Icon(Icons.check,color: Colors.white,size: 14  ,),
  );
}

Widget _uncheck(){
  return Container(
    width: 20,
    height: 20,
    decoration: BoxDecoration(
        border: Border.all(color: primaryColor),
        borderRadius: BorderRadius.circular(4)
    ),
  );
}

