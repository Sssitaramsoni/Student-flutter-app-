import 'package:e_student/util/color_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

Widget lightText(String text, {double size = 14, Color color = Colors.black}) {
  return Text(
    text ?? '',
    style:GoogleFonts.lato(
      fontSize: size,
      color: color,
      fontWeight: FontWeight.w300
    ),
  );
}

Widget regularText(String text, {double size = 14, Color color = Colors.black}) {
  return Text(
    text ?? '',
    style:GoogleFonts.lato(
      fontSize: size,
      color: color,
      fontWeight: FontWeight.normal
    ),
  );
}

Widget semiBoldText(String text, {double size = 14, Color color = Colors.black}) {
  return Text(
    text ?? '',
    style:GoogleFonts.lato(
      fontSize: size,
      color: color,
      fontWeight: FontWeight.w500
    ),
  );
}

Widget boldText(String text, {double size = 14, Color color = Colors.black}) {
  return Text(
    text ?? '',
    style:GoogleFonts.lato(
      fontSize: size,
      color: color,
      fontWeight: FontWeight.bold
    ),
  );
}

TextStyle hintStyle(){
  return GoogleFonts.lato(fontSize: 14,color: Colors.grey);
}

TextStyle textFieldStyle(){
  return GoogleFonts.lato(fontSize: 15,color: primaryColor,fontWeight: FontWeight.normal);
}
