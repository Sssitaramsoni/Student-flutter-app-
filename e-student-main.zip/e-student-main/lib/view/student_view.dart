import 'package:flutter/material.dart';

class StudentView extends StatefulWidget {
  const StudentView({Key key}) : super(key: key);

  @override
  _StudentViewState createState() => _StudentViewState();
}

class _StudentViewState extends State<StudentView> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
