import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';

Widget button(
    {@required String text, @required VoidCallback onClick,Color textColor = Colors.white ,Color color = primaryColor}) {
  return ElevatedButton(
    onPressed: onClick,
    child: regularText(
      text,
      size: 16,
      color: textColor,
    ),
    style: ElevatedButton.styleFrom(
      primary: color,
    ),
  );
}
