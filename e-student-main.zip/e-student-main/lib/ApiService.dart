import 'package:http/http.dart' as http;
import 'dart:convert';

class ApiServices {
  Future apiCallLogin(Map<String, dynamic> param) async {
    var url = Uri.parse('https://schoolzillaserver.schoolzilla.in/login');

    var response = await http.post(
      url,
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
      body: json.encode(param),
    );

    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');

    final data = jsonDecode(response.body);
    // return LoginApiResponse(token: data["token"], error: data["error"], statusCode: response.statusCode);
    return data;
  }
}

class LoginApiResponse {
  final String token;
  final String error;
  final int statusCode;

  LoginApiResponse({this.token, this.error, this.statusCode});
}
