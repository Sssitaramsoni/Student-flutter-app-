import 'package:e_student/Post.dart';
import 'package:e_student/Services.dart';
import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/custom_widget.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FeeDetailListView extends StatefulWidget {
  @override
  _FeeDetailListViewState createState() => _FeeDetailListViewState();
}

class _FeeDetailListViewState extends State<FeeDetailListView> {
  List<Post> posts;
  bool loading;

  @override
  void initState() {
    super.initState();
    getData();
  }

  getData() async {
    loading = true;
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String token = await prefs.getString('token').toString();
    String instituteId = await prefs.getString('instituteId').toString();
    Services.getPosts(token, instituteId).then((list) {
      setState(() {
        posts = list;
        print("from This Screen");
        print(posts[0].name.toString());
        loading = false;
      });
    });
  }

  List<String> items = ['', '', ''];
  String selected;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: semiBoldText('Fee Details', size: 16, color: Colors.white),
      ),
      body: Column(
        children: [
          Container(
              padding: const EdgeInsets.all(10),
              color: Colors.white,
              child: posts != null
                  ? DropdownButton(
                      isExpanded: true,
                      hint: Text('Select from list'),
                      elevation: 2,
                      icon: Icon(Icons.keyboard_arrow_down_sharp),
                      iconDisabledColor: Colors.grey,
                      iconEnabledColor: Theme.of(context).primaryColor,
                      items: posts.map((item) {
                        return new DropdownMenuItem(
                          child: new Text(item.name),
                          value: item.name.toString(),
                        );
                      }).toList(),
                      onChanged: (newVal) {
                        setState(() {
                          selected = newVal;
                          print(selected);
                        });
                      },
                      value: selected,
                    )
                  : Text("Wait Students")),
          
          const SizedBox(
            height: 6,
          ),
          HeaderView(label: 'Fees Details'),
          Expanded(
            child: SingleChildScrollView(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: DataTable(
                  columnSpacing: 20,
                  headingRowColor: MaterialStateProperty.resolveWith<Color>(
                      (Set<MaterialState> states) {
                    return primaryColor;
                  }),
                  dataTextStyle: GoogleFonts.lato(color: Colors.black87),
                  columns: [
                    DataColumn(
                      label: regularText('Fees Name', color: Colors.white),
                    ),
                    DataColumn(
                        label: regularText('Total Fees', color: Colors.white)),
                    DataColumn(
                        label: regularText('Paid Amount', color: Colors.white)),
                    DataColumn(
                        label: regularText('Extra Fees', color: Colors.white)),
                    DataColumn(
                        label: regularText('Late Fees', color: Colors.white)),
                    DataColumn(
                        label: regularText('Discount', color: Colors.white)),
                    DataColumn(
                        label: regularText('Remaining', color: Colors.white)),
                  ],
                  rows: [
                    1,
                    2,
                    3,
                    4,
                    5,
                    6,
                    7,
                    8,
                    9,
                    1,
                    1,
                    1,
                    1,
                    1,
                    1,
                    1,
                    1,
                    1,
                    1,
                    1,
                    1,
                    1,
                    1
                  ]
                      .map(
                        (e) => DataRow(
                          cells: [
                            DataCell(
                              Text(
                                'Tuition Fees',
                                style: GoogleFonts.lato(
                                    fontWeight: FontWeight.bold),
                                textAlign: TextAlign.start,
                              ),
                            ),
                            DataCell(
                                Text('25200', textAlign: TextAlign.center)),
                            DataCell(
                                Text('12500', textAlign: TextAlign.center)),
                            DataCell(Text('0', textAlign: TextAlign.center)),
                            DataCell(Text('0', textAlign: TextAlign.center)),
                            DataCell(Text('0', textAlign: TextAlign.center)),
                            DataCell(
                              Text('12700', textAlign: TextAlign.center),
                            ),
                          ],
                        ),
                      )
                      .toList(),
                ),
              ),
            ),

            /* Table(
              defaultVerticalAlignment: TableCellVerticalAlignment.middle,
              defaultColumnWidth: IntrinsicColumnWidth(flex: 2),
              children: [
                TableRow(
                  decoration: BoxDecoration(
                    color: primaryDark,
                  ),
                  children: [
                    TableCell(
                      child: Container(
                        child: Center(child: regularText('Fees Name',color: Colors.white)),
                      ),
                    ),
                    TableCell(
                      child: Container(
                        child: regularText('Total Fees',color: Colors.white),
                      ),
                    ),
                    TableCell(
                      child: Container(
                        child: regularText('Paid Amount',color: Colors.white),
                      ),
                    ),
                    TableCell(
                      child: Container(
                        child: regularText('Extra Fee',color: Colors.white),
                      ),
                    ),
                    TableCell(
                      child: Container(
                        child: regularText('Late Fee',color: Colors.white),
                      ),
                    ),
                    TableCell(
                      child: Container(
                        child: regularText('Discount',color: Colors.white),
                      ),
                    ),
                    TableCell(
                      child: Container(
                        child: regularText('Remaining',color: Colors.white),
                      ),
                    ),
                  ],
                )
              ],
            )*/
          ),
        ],
      ),
    );
  }
}
