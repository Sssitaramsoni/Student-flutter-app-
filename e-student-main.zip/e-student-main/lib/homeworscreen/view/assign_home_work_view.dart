import 'package:e_student/homescreen/view/teacher_home_view.dart';
import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AssignHomeWorkView extends StatefulWidget {
  const AssignHomeWorkView({Key key}) : super(key: key);

  @override
  _AssignHomeWorkViewState createState() => _AssignHomeWorkViewState();
}

class _AssignHomeWorkViewState extends State<AssignHomeWorkView> {

  final TextEditingController _homeWork = TextEditingController();
  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _submittedDateController = TextEditingController();
  final TextEditingController _comment = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: semiBoldText('Assign Home Work',size: 16,color: Colors.white),
      ),
      body: Container(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Container(
              color: Colors.white,
              padding: const EdgeInsets.all(10 ),
              child: TextField(
                controller: _homeWork,
                maxLines: 1,
                minLines: 1,
                style: GoogleFonts.lato(
                  fontSize: 14,
                  color: primaryColor,
                ),
                keyboardType: TextInputType.multiline,
                textInputAction: TextInputAction.next,
                decoration: InputDecoration(
                  hintText: 'Home work *',
                  hintStyle:GoogleFonts.lato(
                    fontSize: 14,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 10,),

            Container(
              color: Colors.white,
              padding: const EdgeInsets.all(10 ),
              child: TextField(
                controller: _dateController,
                maxLines: 1,
                minLines: 1,
                readOnly: true,
                style: GoogleFonts.lato(
                  fontSize: 14,
                  color: primaryColor,
                ),
                keyboardType: TextInputType.datetime,
                textInputAction: TextInputAction.done,
                decoration: InputDecoration(
                    hintText: 'Assign date *',
                    hintStyle:GoogleFonts.lato(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                    suffixIcon: InkWell(
                      onTap:_datePicker,
                      child: Icon(Icons.calendar_today,color: primaryColor,),
                    )
                ),
              ),
            ),

            const SizedBox(height: 10,),

            Container(
              color: Colors.white,
              padding: const EdgeInsets.all(10 ),
              child: TextField(
                controller: _submittedDateController,
                maxLines: 1,
                minLines: 1,
                readOnly: true,
                style: GoogleFonts.lato(
                  fontSize: 14,
                  color: primaryColor,
                ),
                keyboardType: TextInputType.datetime,
                textInputAction: TextInputAction.done,
                decoration: InputDecoration(
                    hintText: 'Submitted Date *',
                    hintStyle:GoogleFonts.lato(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                    suffixIcon: InkWell(
                      onTap:_datePicker1,
                      child: Icon(Icons.calendar_today,color: primaryColor,),
                    )
                ),
              ),
            ),
            const SizedBox(height: 10,),
            Container(
              color: Colors.white,
              padding: const EdgeInsets.all(10 ),
              child: TextField(
                controller: _comment,
                maxLines: 5,
                minLines: 1,
                style: GoogleFonts.lato(
                  fontSize: 14,
                  color: primaryColor,
                ),
                keyboardType: TextInputType.multiline,
                textInputAction: TextInputAction.done,
                decoration: InputDecoration(
                  hintText: 'Comment *',
                  hintStyle:GoogleFonts.lato(
                    fontSize: 14,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),

            Spacer(),
          ],
        ),
      ),
      bottomNavigationBar: GestureDetector(
        onTap: (){
          Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_)=>TeacherHomeView()), (route) => false);
        },
        child: Container(
          height: 50,
          color: primaryDark,
          alignment: Alignment.center,
          child: semiBoldText('Assign',color: Colors.white,),
        ),
      ),
    );
  }

  void _datePicker()async{
    showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(Duration(days: 30)),
    ).then((value) =>value!=null? setState((){_dateController.text=value.toString();}):null);
  }

  void _datePicker1()async{
    showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(Duration(days: 30)),
    ).then((value) =>value!=null? setState((){_submittedDateController.text=value.toString();}):null);
  }
}
