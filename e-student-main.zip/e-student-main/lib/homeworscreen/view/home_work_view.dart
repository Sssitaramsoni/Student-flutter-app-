import 'package:e_student/view/button.dart';
import 'package:e_student/view/custom_widget.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';

class HomeWorkView extends StatefulWidget {
  const HomeWorkView({Key key}) : super(key: key);

  @override
  _HomeWorkViewState createState() => _HomeWorkViewState();
}

class _HomeWorkViewState extends State<HomeWorkView> {

  final _editDateController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: semiBoldText('Homework',size: 16,color: Colors.white),
      ),
      body: ResponsiveContainer(
        context: context,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _editDateController,
                      readOnly: true,
                      style: textFieldStyle(),
                      decoration: InputDecoration(
                        hintText: 'Assigned Date*',
                        hintStyle: hintStyle(),
                        suffixIcon: IconButton(
                          icon: Icon(Icons.calendar_today,color: Theme.of(context).primaryColor,),
                          onPressed: _datePicker,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10,),
                  button(text: 'Get Home Work', onClick: (){},color: Colors.green)
                ],
              ),
            ),

            HeaderView(label: 'Assigned Home Work'),

            Expanded(child: ListView(
              children: [0,1,2,1,2,0,1,0,2].map((e) => Card(
                child: ListTile(
                  title: boldText('Subject Name',size: 18),
                  subtitle: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          children: [
                            regularText('Subject',size: 14,color: Colors.grey),
                            regularText('Maths',size: 14),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          children: [
                            regularText('Subject code',size: 14,color: Colors.grey),
                            regularText('#Math001',size: 14),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          children: [
                            regularText('Submitted date',size: 14,color: Colors.grey),
                            regularText('20 Aug 2021',size: 14),
                          ],
                        ),
                      )
                    ],
                  ),
                  trailing: _status(e),
                ),
              )).toList(),
            ))
          ],
        ),
      ),
    );
  }

  void _datePicker()async{
    showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(Duration(days: 30)),
    ).then((value) =>value!=null? setState((){_editDateController.text=value.toString();}):null);
  }
  
  Widget _status(e){
    if(e==0)
      return semiBoldText('Incomplete',size: 12,color: Colors.deepOrange);
    if(e==1)
      return semiBoldText('Complete',size: 12,color: Colors.green);
    if(e==2)
      return semiBoldText('✓ Checked',size: 12,color: Colors.green);
  }
}
