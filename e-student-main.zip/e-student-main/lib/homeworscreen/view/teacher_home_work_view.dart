import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/button.dart';
import 'package:e_student/view/custom_widget.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';

class TeacherHomeWorkView extends StatefulWidget {
  const TeacherHomeWorkView({Key key}) : super(key: key);

  @override
  _TeacherHomeWorkViewState createState() => _TeacherHomeWorkViewState();
}

class _TeacherHomeWorkViewState extends State<TeacherHomeWorkView> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: semiBoldText('Homework',size: 16,color: Colors.white),
      ),
      body: ResponsiveContainer(
        context: context,
        child: Column(
          children: [
            Expanded(child: ListView(
              children: [0,1,2,1,2,0,1,0,2].map((e) => Card(
                child: ListTile(
                  title: boldText('Home Work',size: 18),
                  subtitle: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          children: [
                            regularText('Submitted date',size: 14,color: Colors.grey),
                            const SizedBox(width: 10,),
                            regularText('20 Aug 2021',size: 14),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          children: [
                            regularText('Name',size: 14,color: Colors.grey),
                            const SizedBox(width: 10,),
                            regularText('Deepak H Gupta',size: 14),
                          ],
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          if(e==0)
                         FittedBox(
                           child: button(
                             text: 'Make complete',
                             color: Colors.green,
                             onClick: (){},
                           ),
                         ),
                         if(e==1)
                         FittedBox(
                           child: button(
                             text: 'Make checked',
                             color: primaryDark,
                             onClick: (){},
                           ),
                         ),
                        ],
                      ),
                    ],
                  ),
                  trailing: _status(e),
                ),
              )).toList(),
            ))
          ],
        ),
      ),
    );
  }

  Widget _status(e){
    if(e==0)
      return semiBoldText('Incomplete',size: 12,color: Colors.deepOrange);
    if(e==1)
      return semiBoldText('Complete',size: 12,color: Colors.green);
    if(e==2)
      return semiBoldText('✓ Checked',size: 12,color: Colors.green);
  }
}
