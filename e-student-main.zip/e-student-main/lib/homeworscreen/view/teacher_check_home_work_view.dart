import 'package:e_student/homescreen/view/teacher_home_view.dart';
import 'package:e_student/homeworscreen/view/home_work_view.dart';
import 'package:e_student/homeworscreen/view/teacher_home_work_view.dart';
import 'package:e_student/model/Dummy.dart';
import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:horizontal_data_table/horizontal_data_table.dart';

class TeacherCheckHomeWorkView extends StatefulWidget {
  const TeacherCheckHomeWorkView({Key key}) : super(key: key);

  @override
  _TeacherCheckHomeWorkViewState createState() => _TeacherCheckHomeWorkViewState();
}

class _TeacherCheckHomeWorkViewState extends State<TeacherCheckHomeWorkView> {

  final TextEditingController _dateController = TextEditingController();

  List<Dummy> _section =List.generate(20, (index) =>  Dummy(
      id: index,
      selected: false,
      name: 'Marathi',
      surname: 'I',
      assignby: '2',
      section: 'A',
      course: '11th',
      specility: 'Art\'s'
  ));


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: semiBoldText('Assign Home Work',size: 16,color: Colors.white),
      ),
      body: Container(
        child: Column(
          children: [
            Expanded(
              child: HorizontalDataTable(
                leftHandSideColumnWidth: 120,
                rightHandSideColumnWidth: 500,
                isFixedHeader: true,
                headerWidgets: _getTitleWidget(),
                leftSideItemBuilder: _generateFirstColumnRow,
                rightSideItemBuilder: _generateRightHandSideColumnRow,
                itemCount: _section.length,
                rowSeparatorWidget: const Divider(
                  color: Colors.black54,
                  height: 1.0,
                  thickness: 0.0,
                ),
                leftHandSideColBackgroundColor: Color(0xFFFFFFFF),
                rightHandSideColBackgroundColor: Color(0xFFFFFFFF),
                verticalScrollbarStyle: const ScrollbarStyle(
                  isAlwaysShown: true,
                  thickness: 4.0,
                  radius: Radius.circular(5.0),
                ),
                horizontalScrollbarStyle: const ScrollbarStyle(
                  isAlwaysShown: true,
                  thickness: 4.0,
                  radius: Radius.circular(5.0),
                ),
                enablePullToRefresh: false,
              ),
            ),
            const SizedBox(height: 10,),

            Container(
              color: Colors.white,
              padding: const EdgeInsets.all(10 ),
              child: TextField(
                controller: _dateController,
                maxLines: 1,
                minLines: 1,
                readOnly: true,
                style: GoogleFonts.lato(
                  fontSize: 14,
                  color: primaryColor,
                ),
                keyboardType: TextInputType.datetime,
                textInputAction: TextInputAction.done,
                decoration: InputDecoration(
                    hintText: 'Assign Date *',
                    hintStyle:GoogleFonts.lato(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                    suffixIcon: InkWell(
                      onTap:_datePicker,
                      child: Icon(Icons.calendar_today,color: primaryColor,),
                    )
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar:_section.any((element) => element.selected)? GestureDetector(
        onTap: (){
          Navigator.of(context).push(MaterialPageRoute(builder: (_)=>TeacherHomeWorkView()));
        },
        child: Container(
          height: 50,
          color: primaryDark,
          alignment: Alignment.center,
          child: semiBoldText('Continue',color: Colors.white,),
        ),
      ):SizedBox(height: 1,),
    );
  }

  void _datePicker()async{
    showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(Duration(days: 30)),
    ).then((value) =>value!=null? setState((){_dateController.text=value.toString();}):null);
  }

  Widget _getTitleItemWidget(String label, double width) {
    return Container(
      child: Text(label, style: GoogleFonts.lato(fontWeight: FontWeight.bold,color: Colors.white)),
      width: width,
      height: 56,
      color: primaryColor,
      padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
      alignment: Alignment.center,
    );
  }

  List<Widget> _getTitleWidget() {
    return [
      _getTitleItemWidget('Name', 120),
      _getTitleItemWidget('Section', 100),
      _getTitleItemWidget('Semester', 100),
      _getTitleItemWidget('Batch Year', 100),
      _getTitleItemWidget('Speciality', 100),
      _getTitleItemWidget('Course', 100),
    ];
  }

  Widget _generateFirstColumnRow(BuildContext context, int index) {
    return Container(
      child: Text(_section[index].name),
      width: 120,
      height: 52,
      padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
      alignment: Alignment.center,
    );
  }

  Widget _generateRightHandSideColumnRow(BuildContext context, int index) {
    return GestureDetector(
      onTap: (){
        setState(() {
          _section[index].selected = !_section[index].selected;
        });
      },
      child: Container(
        color: _section[index].selected?primaryColor.withOpacity(0.1):Colors.white,
        child: Row(
          children: <Widget>[
            Container(
              child: Text('A'),
              width: 100,
              height: 52,
              padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
              alignment: Alignment.center,
            ),
            Container(
              child: Text('I'),
              width: 100,
              height: 52,
              padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
              alignment: Alignment.center,
            ),
            Container(
              child: Text('1'),
              width: 100,
              height: 52,
              padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
              alignment: Alignment.center,
            ),
            Container(
              child: Text('Art\'s'),
              width: 100,
              height: 52,
              padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
              alignment: Alignment.center,
            ),
            Container(
              child: Text('11th'),
              width: 100,
              height: 52,
              padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
              alignment: Alignment.center,
            ),
          ],
        ),
      ),
    );
  }
}
