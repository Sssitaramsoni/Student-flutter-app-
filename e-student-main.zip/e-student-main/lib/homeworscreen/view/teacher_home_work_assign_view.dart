import 'package:e_student/model/Dummy.dart';
import 'package:e_student/studentscreen/view/student_list_view.dart';
import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:horizontal_data_table/horizontal_data_table.dart';

class TeacherHomeHomeAssignView extends StatefulWidget {

  const TeacherHomeHomeAssignView({Key key}) : super(key: key);

  @override
  _TeacherHomeHomeAssignViewState createState() => _TeacherHomeHomeAssignViewState();
}

class _TeacherHomeHomeAssignViewState extends State<TeacherHomeHomeAssignView> {

  List<Dummy> _section =List.generate(20, (index) =>  Dummy(
    id: index,
    selected: false,
    name: 'Marathi',
    surname: 'I',
    assignby: '2',
    section: 'A',
    course: '11th',
    specility: 'Art\'s'
  ));


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: semiBoldText('Assign Home Work',size: 16,color: Colors.white),
      ),
      body: Container(
        child: HorizontalDataTable(
          leftHandSideColumnWidth: 120,
          rightHandSideColumnWidth: 500,
          isFixedHeader: true,
          headerWidgets: _getTitleWidget(),
          leftSideItemBuilder: _generateFirstColumnRow,
          rightSideItemBuilder: _generateRightHandSideColumnRow,
          itemCount: _section.length,
          rowSeparatorWidget: const Divider(
            color: Colors.black54,
            height: 1.0,
            thickness: 0.0,
          ),
          leftHandSideColBackgroundColor: Color(0xFFFFFFFF),
          rightHandSideColBackgroundColor: Color(0xFFFFFFFF),
          verticalScrollbarStyle: const ScrollbarStyle(
            isAlwaysShown: true,
            thickness: 4.0,
            radius: Radius.circular(5.0),
          ),
          horizontalScrollbarStyle: const ScrollbarStyle(
            isAlwaysShown: true,
            thickness: 4.0,
            radius: Radius.circular(5.0),
          ),
          enablePullToRefresh: false,
        ),
      ),
      bottomNavigationBar:_section.any((element) => element.selected)? GestureDetector(
        onTap: (){
          Navigator.of(context).push(MaterialPageRoute(builder: (_)=>StudentListView( )));
        },
        child: Container(
          height: 50,
          color: primaryDark,
          alignment: Alignment.center,
          child: semiBoldText('Continue',color: Colors.white,),
        ),
      ):SizedBox(height: 1,),
    );
  }

  Widget _getTitleItemWidget(String label, double width) {
    return Container(
      child: Text(label, style: GoogleFonts.lato(fontWeight: FontWeight.bold,color: Colors.white)),
      width: width,
      height: 56,
      color: primaryColor,
      padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
      alignment: Alignment.center,
    );
  }

  List<Widget> _getTitleWidget() {
    return [
      _getTitleItemWidget('Name', 120),
      _getTitleItemWidget('Section', 100),
      _getTitleItemWidget('Semester', 100),
      _getTitleItemWidget('Batch Year', 100),
      _getTitleItemWidget('Speciality', 100),
      _getTitleItemWidget('Course', 100),
    ];
  }

  Widget _generateFirstColumnRow(BuildContext context, int index) {
    return Container(
      child: Text(_section[index].name),
      width: 120,
      height: 52,
      padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
      alignment: Alignment.center,
    );
  }

  Widget _generateRightHandSideColumnRow(BuildContext context, int index) {
    return GestureDetector(
      onTap: (){
        setState(() {
          _section[index].selected = !_section[index].selected;
        });
      },
      child: Container(
        color: _section[index].selected?primaryColor.withOpacity(0.1):Colors.white,
        child: Row(
          children: <Widget>[
            Container(
              child: Text('A'),
              width: 100,
              height: 52,
              padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
              alignment: Alignment.center,
            ),
            Container(
              child: Text('I'),
              width: 100,
              height: 52,
              padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
              alignment: Alignment.center,
            ),
            Container(
              child: Text('1'),
              width: 100,
              height: 52,
              padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
              alignment: Alignment.center,
            ),
            Container(
              child: Text('Art\'s'),
              width: 100,
              height: 52,
              padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
              alignment: Alignment.center,
            ),
            Container(
              child: Text('11th'),
              width: 100,
              height: 52,
              padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
              alignment: Alignment.center,
            ),
          ],
        ),
      ),
    );
  }


}
