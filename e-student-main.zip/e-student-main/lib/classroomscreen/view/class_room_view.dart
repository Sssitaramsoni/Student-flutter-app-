import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_calendar_carousel/classes/event.dart';
import 'package:flutter_calendar_carousel/classes/event_list.dart';
import 'package:flutter_calendar_carousel/flutter_calendar_carousel.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class ClassRoomView extends StatefulWidget {
  @override
  _ClassRoomViewState createState() => _ClassRoomViewState();
}

class _ClassRoomViewState extends State<ClassRoomView> {

  DateTime _currentDate = DateTime.now();
  DateTime _eventDate = DateTime.now();

  static Widget _eventIcon = new CircleAvatar(
    maxRadius: 6,
    backgroundColor: Colors.deepPurple,
  );

   EventList<Event> _markedDateMap;


  @override
  void initState() {
    super.initState();

    _markedDateMap = new EventList<Event>(
      events: {
        DateTime(_eventDate.year,_eventDate.month,_eventDate.day): [
          Event(
            date: DateTime(_eventDate.year,_eventDate.month,_eventDate.day),
            title: 'Chemistry',
            icon: _eventIcon,
            dot: Container(
              margin: EdgeInsets.symmetric(horizontal: 1.0),
              color: Colors.red,
              height: 5.0,
              width: 5.0,
            ),
          ),
          Event(
            date: DateTime(_eventDate.year,_eventDate.month,_eventDate.day),
            title: 'Maths',
            icon: _eventIcon,
            dot: Container(
              margin: EdgeInsets.symmetric(horizontal: 1.0),
              color: Colors.blue,
              height: 5.0,
              width: 5.0,
            ),
          ),
          Event(
            date: DateTime(_eventDate.year,_eventDate.month,_eventDate.day),
            title: 'Physics',
            icon: _eventIcon,
            dot: Container(
              margin: EdgeInsets.symmetric(horizontal: 1.0),
              color: Colors.green,
              height: 5.0,
              width: 5.0,
            ),
          ),
        ],

        DateTime(_eventDate.year,_eventDate.month,_eventDate.day+1): [
          Event(
            date: DateTime(_eventDate.year,_eventDate.month,_eventDate.day+1),
            title: 'Chemistry',
            icon: _eventIcon,
            dot: Container(
              margin: EdgeInsets.symmetric(horizontal: 1.0),
              color: Colors.red,
              height: 5.0,
              width: 5.0,
            ),
          ),
        ],

        DateTime(_eventDate.year,_eventDate.month,_eventDate.day+2): [
          Event(
            date: DateTime(_eventDate.year,_eventDate.month,_eventDate.day+2),
            title: 'Maths',
            icon: _eventIcon,
            dot: Container(
              margin: EdgeInsets.symmetric(horizontal: 1.0),
              color: Colors.blue,
              height: 5.0,
              width: 5.0,
            ),
          ),
          Event(
            date: DateTime(_eventDate.year,_eventDate.month,_eventDate.day+2),
            title: 'Physics',
            icon: _eventIcon,
            dot: Container(
              margin: EdgeInsets.symmetric(horizontal: 1.0),
              color: Colors.green,
              height: 5.0,
              width: 5.0,
            ),
          ),
        ],

      },
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:  AppBar(
        title: semiBoldText('Class Room',size: 16,color: Colors.white),
      ),
      body: Container(
        child: Column(
          children: [
            Expanded(
              flex: 2,
              child: CalendarCarousel<Event>(
                pageScrollPhysics: NeverScrollableScrollPhysics(),
                showOnlyCurrentMonthDate: true,
                onDayPressed: (DateTime date, List<Event> events) {
                  this.setState(() {
                    _currentDate = date;
                    _setEvent();
                  });

                },
                weekendTextStyle: GoogleFonts.lato(
                  color: Colors.red,
                  fontWeight: FontWeight.bold,
                ),
                thisMonthDayBorderColor: Colors.grey,
                daysTextStyle: GoogleFonts.lato(
                  color: Theme.of(context).primaryColor,
                  fontWeight: FontWeight.bold,
                ),
                selectedDayBorderColor: Theme.of(context).primaryColor,
                selectedDayButtonColor: Theme.of(context).primaryColor,
                selectedDayTextStyle: GoogleFonts.lato(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
                weekdayTextStyle: GoogleFonts.lato(
                  color: Theme.of(context).primaryColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
                headerTextStyle: GoogleFonts.lato(
                  color: Theme.of(context).primaryColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 22,
                ),
                iconColor: Theme.of(context).primaryColor,
//      weekDays: null, /// for pass null when you do not want to render weekDays
//      headerText: Container( /// Example for rendering custom header
//        child: Text('Custom Header'),
//      ),
                customDayBuilder: (   /// you can provide your own build function to make custom day containers
                    bool isSelectable,
                    int index,
                    bool isSelectedDay,
                    bool isToday,
                    bool isPrevMonthDay,
                    TextStyle textStyle,
                    bool isNextMonthDay,
                    bool isThisMonthDay,
                    DateTime day,
                    ) {
                  /// If you return null, [CalendarCarousel] will build container for current [day] with default function.
                  /// This way you can build custom containers for specific days only, leaving rest as default.

                  if(day.weekday==7){
                    return Center(
                            child: Icon(Icons.fastfood,color: primaryDark,size: 16,),
                    );
                  }

                  // Example: every 15th of month, we have a flight, we can place an icon in the container like that:
                  // if (day.day == 15) {
                  //   return Center(
                  //     child: Icon(Icons.local_airport),
                  //   );
                  // } else {
                  //   return null;
                  // }

                  // return Container(
                  //   width: MediaQuery.of(context).size.width/7,
                  //   height: MediaQuery.of(context).size.height/7,
                  //   child: Text(day.day.toString()),
                  // );

                  return null;
                },
                weekFormat: false,
                markedDatesMap: _markedDateMap,
                height: 420.0,
                selectedDateTime: _currentDate,
                childAspectRatio: 0.9,
                daysHaveCircularBorder: false, /// null for not rendering any border, true for circular border, false for rectangular border
              ),
            ),
            Container(alignment: Alignment.centerLeft,padding:const EdgeInsets.all(10),child: semiBoldText('Today\'s lecture:',)),
            Expanded(child: ListView(children: _todaysEvent.map((e) => ListTile(
              leading: Icon(Icons.menu_book,color: primaryColor,),
              trailing: e.dot,
              title: semiBoldText(e.title),
            )).toList(),))
          ],
        ),
      ),
    );
  }

  List<Event> _todaysEvent = [];

  void _setEvent(){

    _todaysEvent = _markedDateMap.getEvents(_currentDate)??[];

    setState(() {

    });
  }
}
