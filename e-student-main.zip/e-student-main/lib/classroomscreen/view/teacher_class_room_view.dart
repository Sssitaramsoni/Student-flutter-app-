import 'package:e_student/classroomscreen/view/class_room_view.dart';
import 'package:e_student/model/Dummy.dart';
import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/custom_widget.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:horizontal_data_table/horizontal_data_table.dart';

class TeacherClassRoomView extends StatefulWidget {
  const TeacherClassRoomView({Key key}) : super(key: key);

  @override
  _TeacherClassRoomViewState createState() => _TeacherClassRoomViewState();
}

class _TeacherClassRoomViewState extends State<TeacherClassRoomView> {

  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _startTime = TextEditingController();
  final TextEditingController _endTime = TextEditingController();
  final TextEditingController _password = TextEditingController();

  List<Dummy> _section =List.generate(6, (index) =>  Dummy(
      id: index,
      selected: false,
      name: 'Marathi',
      surname: 'I',
      assignby: '2',
      section: 'A',
      course: '11th',
      specility: 'Art\'s'
  ));


  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: semiBoldText('Class Room',size: 16,color: Colors.white),
        actions: [
          IconButton(onPressed: (){
            Navigator.of(context).push(MaterialPageRoute(builder: (_)=>ClassRoomView(),fullscreenDialog: true));
          }, icon: Icon(Icons.calendar_today_outlined))
        ],
      ),
      body: Column(
        children: [
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(10 ),
            child: TextField(
              controller: _titleController,
              maxLines: 1,
              minLines: 1,
              style: GoogleFonts.lato(
                fontSize: 14,
                color: primaryColor,
              ),
              keyboardType: TextInputType.text,
              textInputAction: TextInputAction.next,
              decoration: InputDecoration(
                hintText: 'Title *',
                hintStyle:GoogleFonts.lato(
                  fontSize: 14,
                  color: Colors.grey,
                ),
              ),
            ),
          ),
          Container(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      color: Colors.white,
                      padding: const EdgeInsets.all(10 ),
                      child: TextField(
                        controller: _startTime,
                        maxLines: 1,
                        minLines: 1,
                        readOnly: true,
                        style: GoogleFonts.lato(
                          fontSize: 14,
                          color: primaryColor,
                        ),
                        keyboardType: TextInputType.text,
                        textInputAction: TextInputAction.next,
                        decoration: InputDecoration(
                          hintText: 'Start time *',
                          hintStyle:GoogleFonts.lato(
                            fontSize: 14,
                            color: Colors.grey,
                          ),
                            suffixIcon: InkWell(
                              onTap:()=>_timePicker(1),
                              child: Icon(Icons.watch_later_outlined,color: primaryColor,),
                            )
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10,),
                  Expanded(
                    child: Container(
                      color: Colors.white,
                      padding: const EdgeInsets.all(10 ),
                      child: TextField(
                        controller: _endTime,
                        maxLines: 1,
                        minLines: 1,
                        readOnly: true,
                        style: GoogleFonts.lato(
                          fontSize: 14,
                          color: primaryColor,
                        ),
                        keyboardType: TextInputType.text,
                        textInputAction: TextInputAction.next,
                        decoration: InputDecoration(
                          hintText: 'End time *',
                          hintStyle:GoogleFonts.lato(
                            fontSize: 14,
                            color: Colors.grey,
                          ),
                            suffixIcon: InkWell(
                              onTap:()=>_timePicker(2),
                              child: Icon(Icons.watch_later_outlined,color: primaryColor,),
                            )
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(10 ),
            child: TextField(
              controller: _password,
              maxLines: 1,
              minLines: 1,
              obscureText: true,
              obscuringCharacter: '*',
              style: GoogleFonts.lato(
                fontSize: 14,
                color: primaryColor,
              ),
              keyboardType: TextInputType.text,
              textInputAction: TextInputAction.next,
              decoration: InputDecoration(
                hintText: 'Password *',
                hintStyle:GoogleFonts.lato(
                  fontSize: 14,
                  color: Colors.grey,
                ),
              ),
            ),
          ),
          HeaderView(label: 'Select subject'),
          Expanded(
            child: Container(
              child: HorizontalDataTable(
                leftHandSideColumnWidth: 120,
                rightHandSideColumnWidth: 500,
                isFixedHeader: true,
                headerWidgets: _getTitleWidget(),
                leftSideItemBuilder: _generateFirstColumnRow,
                rightSideItemBuilder: _generateRightHandSideColumnRow,
                itemCount: _section.length,
                rowSeparatorWidget: const Divider(
                  color: Colors.black54,
                  height: 1.0,
                  thickness: 0.0,
                ),
                leftHandSideColBackgroundColor: Color(0xFFFFFFFF),
                rightHandSideColBackgroundColor: Color(0xFFFFFFFF),
                verticalScrollbarStyle: const ScrollbarStyle(
                  isAlwaysShown: true,
                  thickness: 4.0,
                  radius: Radius.circular(5.0),
                ),
                horizontalScrollbarStyle: const ScrollbarStyle(
                  isAlwaysShown: true,
                  thickness: 4.0,
                  radius: Radius.circular(5.0),
                ),
                enablePullToRefresh: false,
              ),
            ),
          )
        ],
      ),
      bottomNavigationBar: GestureDetector(
        onTap:_section.any ((element) => element.selected)?(){
          Navigator.of(context).pop(false);
        }:null,
        child: Container(
          height: 50,
          color: primaryDark,
          alignment: Alignment.center,
          child: semiBoldText('Submit',color: Colors.white,),
        ),
      ),
    );
  }

  _timePicker(int i) {
    showTimePicker(
        context: context,
        builder: (context, child) {
          return Theme(data: ThemeData.light().copyWith(
            primaryColor: primaryColor,
            colorScheme: ColorScheme.light(primary: primaryColor)
          ), child: child);
        },
        initialTime: TimeOfDay.now()).then((value){
        if(value!=null){
          setState(() {
            if(i==1)
              _startTime.text=value.format(context);
            else
              _endTime.text = value.format(context);
          });
        }
    },
    );
  }


  Widget _getTitleItemWidget(String label, double width) {
    return Container(
      child: Text(label, style: GoogleFonts.lato(fontWeight: FontWeight.bold,color: Colors.white)),
      width: width,
      height: 56,
      color: primaryColor,
      padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
      alignment: Alignment.center,
    );
  }

  List<Widget> _getTitleWidget() {
    return [
      _getTitleItemWidget('Name', 120),
      _getTitleItemWidget('Section', 100),
      _getTitleItemWidget('Semester', 100),
      _getTitleItemWidget('Batch Year', 100),
      _getTitleItemWidget('Speciality', 100),
      _getTitleItemWidget('Course', 100),
    ];
  }

  Widget _generateFirstColumnRow(BuildContext context, int index) {
    return Container(
      child: Text(_section[index].name),
      width: 120,
      height: 52,
      padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
      alignment: Alignment.center,
    );
  }

  Widget _generateRightHandSideColumnRow(BuildContext context, int index) {
    return GestureDetector(
      onTap: (){
        setState(() {
          _section[index].selected = !_section[index].selected;
        });
      },
      child: Container(
        color: _section[index].selected?primaryColor.withOpacity(0.1):Colors.white,
        child: Row(
          children: <Widget>[
            Container(
              child: Text('A'),
              width: 100,
              height: 52,
              padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
              alignment: Alignment.center,
            ),
            Container(
              child: Text('I'),
              width: 100,
              height: 52,
              padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
              alignment: Alignment.center,
            ),
            Container(
              child: Text('1'),
              width: 100,
              height: 52,
              padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
              alignment: Alignment.center,
            ),
            Container(
              child: Text('Art\'s'),
              width: 100,
              height: 52,
              padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
              alignment: Alignment.center,
            ),
            Container(
              child: Text('11th'),
              width: 100,
              height: 52,
              padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
              alignment: Alignment.center,
            ),
          ],
        ),
      ),
    );
  }


}
