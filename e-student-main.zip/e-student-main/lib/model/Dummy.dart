class Dummy {
  int id;
  String name;
  String surname;
  String section;
  String assignby;
  String course;
  String specility;
  int status;
  bool selected = false;
  DateTime createdAt = DateTime.now();
  DateTime updatedAt = DateTime.now();

  Dummy(
      {this.id,
      this.name,
      this.surname,
      this.section,
      this.assignby,
      this.status,
      this.createdAt,
      this.updatedAt,
      this.course,
      this.specility,
      this.selected});
}
