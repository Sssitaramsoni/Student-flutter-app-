import 'package:e_student/view/button.dart';
import 'package:e_student/view/custom_widget.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';

class CheckApplicationStatus extends StatefulWidget {
  @override
  _CheckApplicationStatusState createState() => _CheckApplicationStatusState();
}

class _CheckApplicationStatusState extends State<CheckApplicationStatus> {


  String selected;
  String selectedYear;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:  AppBar(
        title: semiBoldText('Application Status',size: 16,color: Colors.white),
      ),
      body: Container(
        child: Column(
          children: [

            Container(
              padding: const EdgeInsets.all(10),
              color: Colors.white,
              child: DropdownButton(
                isExpanded: true,
                hint: Text('Application Type *'),
                value: selected,
                onChanged: (val){
                  setState(() {
                    selected = val;
                    print(selected);
                  });
                },
                items: [
                  DropdownMenuItem(
                    child: regularText('Leave Application'),
                    value: 'Leave Application',
                  ),
                ],
                elevation: 2,
                icon: Icon(Icons.keyboard_arrow_down_sharp),
                iconDisabledColor: Colors.grey,
                iconEnabledColor: Theme.of(context).primaryColor,
              ),
            ),

            const SizedBox(height: 10,),

            Container(
              padding: const EdgeInsets.all(10),
              color: Colors.white,
              child: DropdownButton(
                isExpanded: true,
                hint: Text('Academic Year *'),
                value: selectedYear,
                onChanged: (val){
                  setState(() {
                    selectedYear = val;
                  });
                },
                items: [
                  DropdownMenuItem(
                    child: regularText('2021-2022'),
                    value: '2021-2022',
                  ),
                ],
                elevation: 2,
                icon: Icon(Icons.keyboard_arrow_down_sharp),
                iconDisabledColor: Colors.grey,
                iconEnabledColor: Theme.of(context).primaryColor,
              ),
            ),

            const SizedBox(height: 10,),

            button(text: 'Get Application', onClick: (){},color: Colors.green),

            const SizedBox(height: 10,),

            HeaderView(label: 'Application'),

            Expanded(
              child: ListView(
                children:  [1,2,3,4,5,6,7,8,9,0].map((e) => Card(
                  child:  ListTile(
                    contentPadding: const EdgeInsets.all(10),
                    title: boldText('Application Name',size: 18),
                    subtitle: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 6),
                          child: Row(
                            children: [
                              regularText('Date',size: 14,color: Colors.grey),
                              const SizedBox(width: 10,),
                              regularText('12,Aug 2021',size: 14,color:Colors.black87),
                            ],
                          ),
                        ),
                      ],
                    ),
                    trailing: semiBoldText('Pending',size: 12,color:Colors.red),
                  ),
                )).toList(),
              ),
            )
          ],
        ),
      ),
    );
  }
}
