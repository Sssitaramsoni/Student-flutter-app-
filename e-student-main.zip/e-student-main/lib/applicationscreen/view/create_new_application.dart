import 'package:e_student/applicationscreen/view/check_application_status.dart';
import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/button.dart';
import 'package:e_student/view/custom_widget.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class CreateNewApplication extends StatefulWidget {
  @override
  _CreateNewApplicationState createState() => _CreateNewApplicationState();
}

class _CreateNewApplicationState extends State<CreateNewApplication> {

  final TextEditingController _applicationName = TextEditingController();
  final TextEditingController _reason = TextEditingController();
  final TextEditingController _startDate = TextEditingController();
  final TextEditingController _endDate = TextEditingController();

  String selected;
  var principle = false;
  var teacher = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:  AppBar(
        title: semiBoldText('Create New Application',size: 16,color: Colors.white),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(builder: (_)=>CheckApplicationStatus()));
            },
            icon: Icon(Icons.history),
          ),
        ],
      ),
      body: Container(
        padding: const EdgeInsets.all(10),
        child: SingleChildScrollView(
          child: Column(
            children: [

              Container(
                padding: const EdgeInsets.all(10),
                color: Colors.white,
                child: DropdownButton(
                  isExpanded: true,
                  hint: Text('Application Type *'),
                  value: selected,
                  onChanged: (val){
                    setState(() {
                      selected = val;
                      print(selected);
                    });
                  },
                  items: [
                    DropdownMenuItem(
                      child: regularText('Leave Application'),
                      value: 'Leave Application',
                    ),
                  ],
                  elevation: 2,
                  icon: Icon(Icons.keyboard_arrow_down_sharp),
                  iconDisabledColor: Colors.grey,
                  iconEnabledColor: Theme.of(context).primaryColor,
                ),
              ),

              const SizedBox(height: 10,),

              Container(
                color: Colors.white,
                padding: const EdgeInsets.all(10 ),
                child: TextField(
                  controller: _applicationName,
                  maxLines: 1,
                  minLines: 1,
                  style: GoogleFonts.lato(
                    fontSize: 14,
                    color: primaryColor,
                  ),
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    hintText: 'Application Name *',
                    hintStyle:GoogleFonts.lato(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 10,),

              Container(
                color: Colors.white,
                padding: const EdgeInsets.all( 10),
                child: TextField(
                  controller: _reason,
                  maxLines: 5,
                  minLines: 1,
                  style: GoogleFonts.lato(
                    fontSize: 14,
                    color: primaryColor,
                  ),
                  keyboardType: TextInputType.multiline,
                  textInputAction: TextInputAction.done,
                  decoration: InputDecoration(
                    hintText: 'Reason *',
                    hintStyle:GoogleFonts.lato(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 10,),

              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Container(
                        color: Colors.white,
                        padding: const EdgeInsets.all( 10),
                        child: TextField(
                          controller: _startDate,
                          readOnly: true,
                          maxLines: 1,
                          minLines: 1,
                          style: GoogleFonts.lato(
                            fontSize: 14,
                            color: primaryColor,
                          ),
                          keyboardType: TextInputType.multiline,
                          textInputAction: TextInputAction.done,
                          decoration: InputDecoration(
                            hintText: 'Start Date *',
                            hintStyle:GoogleFonts.lato(
                              fontSize: 14,
                              color: Colors.grey,
                            ),
                            suffixIcon: InkWell(onTap:()=>_showDatePicker(1),child: Icon(Icons.calendar_today_rounded,color: primaryColor,size: 20,),)
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10,),
                    Expanded(
                      child: Container(
                        color: Colors.white,
                        padding: const EdgeInsets.all( 10),
                        child: TextField(
                          controller: _endDate,
                          readOnly: true,
                          maxLines: 1,
                          minLines: 1,
                          style: GoogleFonts.lato(
                            fontSize: 14,
                            color: primaryColor,
                          ),
                          textInputAction: TextInputAction.done,
                          decoration: InputDecoration(
                            hintText: 'End Date *',
                            hintStyle:GoogleFonts.lato(
                              fontSize: 14,
                              color: Colors.grey,
                            ),
                            suffixIcon: InkWell(onTap:()=>_showDatePicker(2),child: Icon(Icons.calendar_today_rounded,color: primaryColor,size: 20,),)
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),

              const SizedBox(height: 10,),

              Container(
                color: Colors.white,
                padding: const EdgeInsets.all( 14),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    AppCheckBox(label: 'To Principle',value: principle,onChanged: (val){
                      setState(() {
                        principle = true;
                        teacher = false;
                      });
                    }),
                    AppCheckBox(label: 'To Teacher',value: teacher,onChanged: (val){
                      setState(() {
                        principle = false;
                        teacher = true;
                      });
                    }),
                  ],
                )
              ),

              const SizedBox(height: 20,),

              button(text: 'Submit Application', onClick: (){},color: Colors.green),

            ],
          ),
        ),
      ),
    );
  }

  void _showDatePicker(int type){
    showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add( Duration(days: 60)),
    ).then((value){
      if(value!=null){
        setState(() {
          if(type==1)
            _startDate.text  = DateFormat('dd,MMM yyyy').format(value);
          else
            _endDate.text  = DateFormat('dd,MMM yyyy').format(value);
        });
      }
    });
  }
}
