import 'package:e_student/libraryscreen/view/library_history_book.dart';
import 'package:e_student/view/custom_widget.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class LibraryListView extends StatefulWidget {
  @override
  _LibraryListViewState createState() => _LibraryListViewState();
}

class _LibraryListViewState extends State<LibraryListView> {
  final TextEditingController _editingController = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  List<int> _books = [1,2,0,0,2,1,2,1,0,2];
  var visible = false;

  @override
  void dispose() {
    _editingController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:  AppBar(
        title: semiBoldText('Library',size: 16,color: Colors.white),
        actions: [
          IconButton(
            onPressed: () {
             setState(() {
               visible=!visible;
             });
            },
            icon: Icon(Icons.search),
          ),

          IconButton(
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(builder: (_)=>LibraryHistoryBook()));
            },
            icon: Icon(Icons.history),
          ),
        ],
      ),
      body: Column(
        children: [
          AnimatedContainer(
            duration: Duration(milliseconds: 500),
            constraints: BoxConstraints(minHeight: 0,maxHeight: visible?60:0),
            height: visible?60:0,
            child: SearchView(
                controller: _editingController,
                focusNode: _focusNode,
                onChange: (val) {},
                onClear: () {
                  setState(() {
                    _editingController.clear();
                  });
                }),
          ),
          Expanded(
            child: ListView.builder(
              itemBuilder: (_, index) {
                return Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(10),
                    title: boldText('Head First Java',size: 18),
                    subtitle: Column(
                      children: [
                        const SizedBox(height: 5,),
                        Divider(),
                        const SizedBox(height: 5,),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            children: [
                              regularText('Author Name',size: 14,color: Colors.grey),
                              const SizedBox(width: 8,),
                              regularText('Bert Bates and Kathy Sierra',size: 14),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            children: [
                              regularText('Publisher',size: 14,color: Colors.grey),
                              const SizedBox(width: 8,),
                              regularText('John Smith',size: 14),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            children: [
                              regularText('Publisher',size: 14,color: Colors.grey),
                              const SizedBox(width: 8,),
                              regularText('John Smith',size: 14),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            children: [
                              regularText('Subject',size: 14,color: Colors.grey),
                              const SizedBox(width: 8,),
                              regularText('Religious',size: 14),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            children: [
                              regularText('Roll No',size: 14,color: Colors.grey),
                              const SizedBox(width: 8,),
                              regularText('${index+1}',size: 14),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            children: [
                              regularText('Catalog',size: 14,color: Colors.grey),
                              const SizedBox(width: 8,),
                              regularText('-',size: 14),
                            ],
                          ),
                        ),
                      ],
                    ),
                    trailing: _status(_books[index]),
                  ),
                );
              },
              itemCount: _books.length,
            ),
          ),
        ],
      ),
    );
  }

  Widget _status(e){
    if(e==0)
      return semiBoldText('Taken',size: 12,color: Colors.deepOrange);
    if(e==1)
      return semiBoldText('Available',size: 12,color: Colors.green);
    if(e==2)
      return semiBoldText('Not available',size: 12,color: Colors.red);
  }
}
