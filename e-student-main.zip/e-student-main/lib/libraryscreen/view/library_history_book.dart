import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';

class LibraryHistoryBook extends StatefulWidget {
  @override
  _LibraryHistoryBookState createState() => _LibraryHistoryBookState();
}

class _LibraryHistoryBookState extends State<LibraryHistoryBook> {
  List<int> _books = [1,2,0,0,2,1,2,1,0,2];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:  AppBar(
        title: semiBoldText('Library History',size: 16,color: Colors.white),
      ),
      body: ListView.builder(
        itemBuilder: (_, index) {
          return Card(
            child: ListTile(
              contentPadding: const EdgeInsets.all(10),
              title: boldText('Head First Java',size: 18),
              subtitle: Column(
                children: [
                  const SizedBox(height: 5,),
                  Divider(),
                  const SizedBox(height: 5,),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        regularText('Subject',size: 14,color: Colors.grey),
                        const SizedBox(width: 8,),
                        regularText('Java',size: 14),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        regularText('ISBN',size: 14,color: Colors.grey),
                        const SizedBox(width: 8,),
                        regularText('#######',size: 14),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        regularText('Author Name',size: 14,color: Colors.grey),
                        const SizedBox(width: 8,),
                        regularText('John Smith',size: 14),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        regularText('Issue Date',size: 14,color: Colors.grey),
                        const SizedBox(width: 8,),
                        regularText('16,July 2021',size: 14),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        regularText('Due Date',size: 14,color: Colors.grey),
                        const SizedBox(width: 8,),
                        regularText('25,July 2021',size: 14),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        regularText('Return Date',size: 14,color: Colors.grey),
                        const SizedBox(width: 8,),
                        regularText('26,July 2021',size: 14),
                      ],
                    ),
                  ),
                ],
              ),
              trailing: _status(_books[index]),
            ),
          );
        },
        itemCount: _books.length,
      ),
    );
  }

  Widget _status(e){
    if(e==0)
      return semiBoldText('Fine : ₹0.0',size: 12,color: Colors.green);
    if(e==1)
      return semiBoldText('Fine : ₹20.00',size: 12,color: Colors.green);
    if(e==2)
      return semiBoldText('Fine : ₹30.00',size: 12,color: Colors.red);
  }
}
