import 'package:e_student/loginscreen/view/login_view.dart';

import '../homescreen/view/home_view.dart';
import 'package:flutter/material.dart';

class SplashView extends StatefulWidget {
  const SplashView({Key key}) : super(key: key);

  @override
  _SplashViewState createState() => _SplashViewState();
}

class _SplashViewState extends State<SplashView> {

  @override
  void initState() {
    super.initState();
    _checkLogin();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Center(
            child: Icon(Icons.menu_book,color: Theme.of(context).primaryColor,size: 100,),
          ),
          Positioned(
            bottom: 20,
            left: 20,
            right: 20,
            child: Center(child: Text('v.1.0.0',style: Theme.of(context).textTheme.caption,)),
          )
        ],
      ),
    );
  }

  ///chek the user is logged in or not
  ///if user is login then this will navigate to home screen
  ///otherwise user will navigate to login screen
  void _checkLogin() {
    Future.delayed(Duration(seconds: 2),(){
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_)=>LoginView()));
    });
  }
}
