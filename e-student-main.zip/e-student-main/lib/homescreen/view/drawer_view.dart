import 'package:e_student/applicationscreen/view/create_new_application.dart';
import 'package:e_student/attendancescreen/view/attendance_screen.dart';
import 'package:e_student/calenderscreen/view/calender_view.dart';
import 'package:e_student/classroomscreen/view/class_room_view.dart';
import 'package:e_student/examinationscreen/view/examination_view.dart';
import 'package:e_student/feedetailscreen/view/fee_detail_list_view.dart';
import 'package:e_student/fees.dart';
import 'package:e_student/grievancescreen/view/create_grievance_view.dart';
import 'package:e_student/homeworscreen/view/home_work_view.dart';
import 'package:e_student/libraryscreen/view/library_list_view.dart';
import 'package:e_student/multimediascreen/view/multimedia_view.dart';
import 'package:e_student/view/custom_widget.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';


class DrawerView extends StatefulWidget {
  const DrawerView({Key key}) : super(key: key);

  @override
  _DrawerViewState createState() => _DrawerViewState();
}

class _DrawerViewState extends State<DrawerView> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      color: Theme.of(context).primaryColor,
      child: ListView(
        children: [
          DrawerHeader(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Icon(
                    Icons.person,
                    color: Theme.of(context).primaryColor,
                  ),
                ),
                const SizedBox(
                  height: 6,
                ),
                semiBoldText('User name', color: Colors.white, size: 14),
                const SizedBox(
                  height: 10,
                ),
                boldText('ahinsa international school'.toUpperCase(),
                    color: Colors.white, size: 16),
              ],
            ),
            duration: Duration(milliseconds: 500),
            curve: Curves.easeInOut,
          ),
          CustomDivider(
            color: Colors.white,
          ),
          _tile('Dashboard', Icons.dashboard, onClick: () {}),
          _tile('Home Work', Icons.work, onClick: () {
            Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => HomeWorkView()));
          }),
          // _tile('Fees', Icons.work, onClick: () {
            
          //   Navigator.of(context)
          //       .push(MaterialPageRoute(builder: (_) => Fees()));
          // }),
          _tile('Calender', Icons.calendar_today_rounded, onClick: () {
            Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => CalenderView()));
          }),
          _tile('Examination', Icons.question_answer, onClick: () {
            Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => ExaminationView()));
          }),
          _tile('Fee Details', Icons.attach_money, onClick: () {
            Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => FeeDetailListView()));
          }),
          _tile('Multimedia', Icons.perm_media_rounded, onClick: () {
            Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => MultimediaView()));
          }),
          _tile('Class Room', Icons.queue_play_next_rounded, onClick: () {
            Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => ClassRoomView()));
          }),
          _tile('Library', Icons.collections_bookmark, onClick: () {
            Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => LibraryListView()));
          }),
          _tile('Attendance', Icons.drive_folder_upload, onClick: () {
            Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => AttendanceView()));
          }),
          _tile('Application', Icons.message_rounded, onClick: () {
            Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => CreateNewApplication()));
          }),
          _tile('Grievance', Icons.message, onClick: () {
            Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => CreateGrievanceView()));
          }),
        ],
      ),
    );
  }

  Widget _tile(String name, IconData icon, {@required VoidCallback onClick}) {
    return ListTile(
      title: regularText(name, color: Colors.white, size: 16),
      trailing: Icon(
        icon,
        color: Colors.white,
        size: 24,
      ),
      onTap: () {
        Navigator.of(context).pop();
        onClick?.call();
      },
    );
  }
}
