import 'package:e_student/notificationscreen/view/notification_view.dart';
import 'package:e_student/view/custom_widget.dart';
import 'package:e_student/view/text.dart';

import '../view/drawer_view.dart';
import 'package:flutter/material.dart';

class HomeView extends StatefulWidget {
  String instituteId;
  HomeView({Key key, this.instituteId}) : super(key: key);

  @override
  _HomeViewState createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  @override
  void initState() {
    
    super.initState();
    print("+++++++++++++++++++++====");
    print("datagint" + widget.instituteId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: semiBoldText('Home', size: 16, color: Colors.white),
        actions: [
          BadgeView(
            child: Icon(Icons.notifications),
            value: 10,
            onClick: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => NotificationView()));
            },
          ),
        ],
      ),
      drawer: Drawer(child: DrawerView()),
      body: ResponsiveContainer(
        context: context,
        child: Column(
          children: [
            Card(
              child: Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 20),
                child: semiBoldText('ahinsa international school'.toUpperCase(),
                    size: 16),
              ),
            )
          ],
        ),
      ),
    );
  }

}
