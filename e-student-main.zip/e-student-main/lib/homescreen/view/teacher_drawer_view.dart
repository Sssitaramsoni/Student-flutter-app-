import 'package:e_student/assessmentscreen/view/assessment_group.dart';
import 'package:e_student/assessmentscreen/view/assessment_view.dart';
import 'package:e_student/calenderscreen/view/teacher_calender_view.dart';
import 'package:e_student/classroomscreen/view/teacher_class_room_view.dart';
import 'package:e_student/fees.dart';
import 'package:e_student/homeworscreen/view/teacher_check_home_work_view.dart';
import 'package:e_student/homeworscreen/view/teacher_home_work_assign_view.dart';
import 'package:e_student/multimediascreen/view/teacher_assign_multimedia_view.dart';
import 'package:e_student/multimediascreen/view/teacher_upload_multimedia_view.dart';
import 'package:e_student/view/custom_widget.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';


class TeacherDrawerView extends StatefulWidget {
  const TeacherDrawerView({Key key}) : super(key: key);

  @override
  _TeacherDrawerViewState createState() => _TeacherDrawerViewState();
}

class _TeacherDrawerViewState extends State<TeacherDrawerView> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      color: Theme.of(context).primaryColor,
      child: ListView(
        children: [
          DrawerHeader(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Icon(Icons.person,color: Theme.of(context).primaryColor,),
                ),
                const SizedBox(height: 6,),
                semiBoldText('User name',color: Colors.white,size: 14),
                const SizedBox(height: 10,),
                boldText('ahinsa international school'.toUpperCase(),color: Colors.white,size: 16),
              ],
            ),
            duration: Duration(milliseconds: 500),
            curve: Curves.easeInOut,
          ),
          CustomDivider(color: Colors.white,),
          _tile('Dashboard', Icons.dashboard,onClick: (){}),

          ExpansionTile(title: regularText('Home Work',color: Colors.white,size: 16),
          trailing: Icon(Icons.keyboard_arrow_down_rounded,color: Colors.white,),
          children: [
            _tile('Assign Home Work', Icons.assignment,onClick: (){
              Navigator.of(context).push(MaterialPageRoute(builder: (_)=>TeacherHomeHomeAssignView()));
            }),
            _tile('Check Home Work', Icons.assignment_turned_in_rounded,onClick: (){
              Navigator.of(context).push(MaterialPageRoute(builder: (_)=>TeacherCheckHomeWorkView()));
            }),
          ],),

          _tile('Calender', Icons.calendar_today_rounded,onClick: (){
            Navigator.of(context).push(MaterialPageRoute(builder: (_)=>TeacherCalenderView()));
          }),

          ExpansionTile(title: regularText('Multimedia',color: Colors.white,size: 16),
            trailing: Icon(Icons.keyboard_arrow_down_rounded,color: Colors.white,),
            children: [
              _tile('Assign Multimedia', Icons.perm_media_rounded,onClick: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (_)=>TeacherAssignMultimediaView()));
              }),
              _tile('Upload Multimedia', Icons.drive_folder_upload,onClick: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (_)=>TeacherUploadMultimediaView()));
              }),
            ],),

          _tile('Class Room', Icons.queue_play_next_rounded,onClick: (){
            Navigator.of(context).push(MaterialPageRoute(builder: (_)=>TeacherClassRoomView()));
          }),

          //  _tile('Fees', Icons.money_outlined,onClick: (){
          //   Navigator.of(context).push(MaterialPageRoute(builder: (_)=>Fees()));
          // }),

          ExpansionTile(title: regularText('Result',color: Colors.white,size: 16),
            trailing: Icon(Icons.keyboard_arrow_down_rounded,color: Colors.white,),
            children: [
              _tile('Term Exam', Icons.message,onClick: (){
                //Navigator.of(context).push(MaterialPageRoute(builder: (_)=>TeacherAssignMultimediaView()));
              }),
              _tile('Assessment', Icons.message,onClick: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (_)=>AssessmentView()));
              }),
              _tile('Assessment Group', Icons.message,onClick: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (_)=>AssessmentGroup()));
              }),
              _tile('Term Assessment', Icons.message,onClick: (){
                //Navigator.of(context).push(MaterialPageRoute(builder: (_)=>TeacherUploadMultimediaView()));
              }),
              _tile('Subject Assessment', Icons.message,onClick: (){
                //Navigator.of(context).push(MaterialPageRoute(builder: (_)=>TeacherUploadMultimediaView()));
              }),
            ],),
          
          //  _tile('Fees Details', Icons.money_outlined,onClick: (){
          //   Navigator.of(context).push(MaterialPageRoute(builder: (_)=>Fees()));
          // }),
          
        ],
      ),
    );
  }

  Widget _tile(String name,IconData icon,{@required VoidCallback onClick}){
    return ListTile(
      title: regularText(name,color: Colors.white,size: 16),
      trailing: Icon(icon,color: Colors.white,size: 24,),
      onTap: (){
        Navigator.of(context).pop();
        onClick?.call();
      },
    );
  }
}
