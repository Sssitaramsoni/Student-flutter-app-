import 'package:e_student/homescreen/view/teacher_drawer_view.dart';
import 'package:e_student/notificationscreen/view/notification_view.dart';
import 'package:e_student/view/custom_widget.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';

class TeacherHomeView extends StatefulWidget {
  const TeacherHomeView({Key key}) : super(key: key);

  @override
  _TeacherHomeViewState createState() => _TeacherHomeViewState();
}

class _TeacherHomeViewState extends State<TeacherHomeView> {
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: semiBoldText('Home', size: 16, color: Colors.white),
        actions: [
          BadgeView(
            child: Icon(Icons.notifications),
            value: 10,
            onClick: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => NotificationView()));
            },
          ),
        ],
      ),
      drawer: Drawer(child: TeacherDrawerView()),
      body: ResponsiveContainer(
        context: context,
        child: Column(
          children: [
            Card(
              child: Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 20),
                child: semiBoldText('ahinsa international school'.toUpperCase(),
                    size: 16),
              ),
            )
          ],
        ),
      ),
    );
  }
}
