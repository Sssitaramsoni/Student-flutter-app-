import 'package:http/http.dart' as http;
import 'Post.dart';

class Services {
 
  static Future<List<Post>> getPosts(token,id) async {
    try {
         String url =
      'https://schoolzillaserver.schoolzilla.in/rest/getallfeetypes/$id';

      final response = await http.get(Uri.parse(url),
       headers: {"Authorisation": "Token $token"});
      

      if (response.statusCode == 200) {
        final List<Post> listPosts = postFromJson(response.body);
        print(response.body);
        return listPosts;
      } else {
        return List<Post>();
      }
    } catch (e) {
      return List<Post>();
    }
  }
}
