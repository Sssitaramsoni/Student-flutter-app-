import 'package:e_student/model/Dummy.dart';
import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/button.dart';
import 'package:e_student/view/custom_widget.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AddNewAssessmentGroup extends StatefulWidget {
  const AddNewAssessmentGroup({Key key}) : super(key: key);

  @override
  _AddNewAssessmentGroupState createState() => _AddNewAssessmentGroupState();
}

class _AddNewAssessmentGroupState extends State<AddNewAssessmentGroup> {

  final TextEditingController _nameController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      height: MediaQuery.of(context).size.height*0.30,
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(10),
            topRight: Radius.circular(10),
          )
      ),
      child: Column(
        children: [
          ClosePopupWidget(),
          Expanded(child: Column(
            children: [
              Container(
                color: Colors.white,
                padding: const EdgeInsets.all(10 ),
                child: TextField(
                  controller: _nameController,
                  maxLines: 1,
                  minLines: 1,
                  style: GoogleFonts.lato(
                    fontSize: 14,
                    color: primaryColor,
                  ),
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    hintText: 'Name *',
                    hintStyle:GoogleFonts.lato(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 10,),
            ],
          ),),
          SizedBox(width: MediaQuery.of(context).size.width,height: 40 ,child: button(text: 'Submit', onClick: (){
            Navigator.of(context).pop();
          }),),
        ],
      ),
    );
  }
}
