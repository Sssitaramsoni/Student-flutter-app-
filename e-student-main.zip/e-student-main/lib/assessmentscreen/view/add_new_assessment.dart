import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/button.dart';
import 'package:e_student/view/custom_widget.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AddNewAssessment extends StatefulWidget {
  const AddNewAssessment({Key key}) : super(key: key);

  @override
  _AddNewAssessmentState createState() => _AddNewAssessmentState();
}

class _AddNewAssessmentState extends State<AddNewAssessment> {

  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _desController = TextEditingController();
  final TextEditingController _maxMarks = TextEditingController();

  var grade = false;
  var nonAcademic= false;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      height: MediaQuery.of(context).size.height*0.60,
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(10),
            topRight: Radius.circular(10),
          )
      ),
      child: Column(
        children: [
          ClosePopupWidget(),
          Expanded(child: ListView(
            children: [
              Container(
                color: Colors.white,
                padding: const EdgeInsets.all(10 ),
                child: TextField(
                  controller: _titleController,
                  maxLines: 1,
                  minLines: 1,
                  style: GoogleFonts.lato(
                    fontSize: 14,
                    color: primaryColor,
                  ),
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    hintText: 'Name *',
                    hintStyle:GoogleFonts.lato(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 10,),

              Container(
                color: Colors.white,
                padding: const EdgeInsets.all(10 ),
                child: TextField(
                  controller: _desController,
                  maxLines: 5,
                  minLines: 1,
                  style: GoogleFonts.lato(
                    fontSize: 14,
                    color: primaryColor,
                  ),
                  keyboardType: TextInputType.multiline,
                  textInputAction: TextInputAction.done,
                  decoration: InputDecoration(
                    hintText: 'Abbreviation *',
                    hintStyle:GoogleFonts.lato(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10,),

              AppCheckBox(value: nonAcademic, onChanged: (val){
                setState(() {
                  nonAcademic = true;
                  grade = false;
                });
              },label: 'Non Academic Grade',),
              const SizedBox(height: 10,),
              AppCheckBox(value: grade, onChanged: (val){
                setState(() {
                  grade = true;
                  nonAcademic = false;
                });
              },label: 'Only Grade',),

              Container(
                color: Colors.white,
                padding: const EdgeInsets.all(10 ),
                child: TextField(
                  controller: _maxMarks,
                  maxLines: 1,
                  minLines: 1,
                  style: GoogleFonts.lato(
                    fontSize: 14,
                    color: primaryColor,
                  ),
                  keyboardType: TextInputType.number,
                  textInputAction: TextInputAction.done,
                  decoration: InputDecoration(
                    hintText: 'Max Marks *',
                    hintStyle:GoogleFonts.lato(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                  ),
                ),
              ),
            ],
          ),),
          SizedBox(width: MediaQuery.of(context).size.width,height: 40 ,child: button(text: 'Submit', onClick: (){
            Navigator.of(context).pop();
          })),
        ],
      ),
    );
  }
}
