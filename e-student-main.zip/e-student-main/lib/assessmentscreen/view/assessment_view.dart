import 'package:e_student/assessmentscreen/view/add_new_assessment.dart';
import 'package:e_student/model/Dummy.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';

class AssessmentView extends StatefulWidget {
  const AssessmentView({Key key}) : super(key: key);

  @override
  _AssessmentViewState createState() => _AssessmentViewState();
}

class _AssessmentViewState extends State<AssessmentView> {

  List<Dummy> _list = [
    Dummy(
      name: 'Test 1',
      surname: 'This is test description',
      section: 'Non Academic Grade',
      status: 80,
    ),
    Dummy(
      name: 'Test 2',
      surname: 'This is test description',
      section: 'Only Grade',
      status: 85,
    ),
    Dummy(
      name: 'Test 3',
      surname: 'This is test description',
      section: 'Non Academic Grade',
      status: 82,
    ),
    Dummy(
      name: 'Test 4',
      surname: 'This is test description',
      section: 'only Grade',
      status: 82,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: semiBoldText('Assessment',size: 16,color: Colors.white),
      ),
      body: Container(
        child: ListView.separated(
          itemCount: _list.length,
          itemBuilder: (_,i)=>ListTile(
            title: boldText(_list[i].name,size: 16),
            subtitle: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  regularText(_list[i].surname),
                  const SizedBox(height: 6,),
                  regularText(_list[i].section,color: Colors.grey),
                ],
              ),
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                boldText('Max Marks\t:\t',color: Colors.grey),
                boldText(_list[i].status.toString(),color: Colors.red),
              ],
            ),
          ),
          separatorBuilder: (_,i)=>Divider(),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: Theme.of(context).primaryColor,
          onPressed: showAddNewPopup, label: Row(
        children: [
          Icon(Icons.add,color: Colors.white,),
          const SizedBox(width: 6,),
          regularText('Add New',color: Colors.white)
        ],
      )),
    );
  }

  void showAddNewPopup(){
    showModalBottomSheet(
      context: context,
      builder: (_) => Padding(
        padding: MediaQuery.of(context).viewInsets,
        child: AddNewAssessment(),
      ),
      isScrollControlled: true,
      isDismissible: true,
      backgroundColor: Colors.transparent,
    );
  }

}

