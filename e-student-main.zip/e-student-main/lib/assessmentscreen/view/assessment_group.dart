import 'package:e_student/assessmentscreen/view/add_new_assessment_group.dart';
import 'package:e_student/model/Dummy.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';

class AssessmentGroup extends StatefulWidget {

  const AssessmentGroup({Key key}) : super(key: key);

  @override
  _AssessmentGroupState createState() => _AssessmentGroupState();
}

class _AssessmentGroupState extends State<AssessmentGroup> {

  List<Dummy> _list = List.generate(10, (index) => Dummy(name: 'Group $index'));


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: semiBoldText('Assessment Group',size: 16,color: Colors.white),
      ),
      body: Container(
        child:  ListView.separated(
          itemCount: _list.length,
          itemBuilder: (_,index)=>ListTile(
            title: boldText(_list[index].name,size: 18),
          ),
          separatorBuilder: (_,index)=>Divider(),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
          backgroundColor: Theme.of(context).primaryColor,
          onPressed: showAddNewPopup, label: Row(
        children: [
          Icon(Icons.add,color: Colors.white,),
          const SizedBox(width: 6,),
          regularText('Add New',color: Colors.white)
        ],
      )),
    );
  }

  void showAddNewPopup() {
    showModalBottomSheet(
      context: context,
      builder: (_) => Padding(
        padding: MediaQuery.of(context).viewInsets,
        child: AddNewAssessmentGroup(),
      ),
      isScrollControlled: true,
      isDismissible: true,
      backgroundColor: Colors.transparent,
    );
  }
}
