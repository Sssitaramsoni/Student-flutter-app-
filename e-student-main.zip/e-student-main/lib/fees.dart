import 'package:shared_preferences/shared_preferences.dart';

import 'Services.dart';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'Post.dart';

class Fees extends StatefulWidget {
  const Fees({Key key}) : super(key: key);

  @override
  _FeesState createState() => _FeesState();
}

class _FeesState extends State<Fees> {
  List<Post> posts;
  bool loading;

  @override
  void initState() {
    super.initState();
    getData();
  }

  getData() async {
    loading = true;
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String token = await prefs.getString('token').toString();
    String instituteId = await prefs.getString('instituteId').toString();
    Services.getPosts(token, instituteId).then((list) {
      setState(() {
        posts = list;
        loading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(loading ? 'Loading...' : 'Posts'),
      ),
      body: Container(
        color: Colors.white,
        child: ListView.builder(
            // shrinkWrap: true,
            itemCount: posts == null ? 0 : posts.length,
            itemBuilder: (context, index) {
              Post post = posts[index];
              return ListTile(
                title: Text(
                  index.toString() + " . " + post.name.toString(),
                  style: TextStyle(fontSize: 20, color: Colors.black),
                ),
                // subtitle: Text(fees1.id),
              );
            }),
      ),
    );
  }
}
