import 'package:e_student/multimediascreen/view/create_media_popup.dart';
import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';

class TeacherUploadMultimediaView extends StatefulWidget {
  const TeacherUploadMultimediaView({Key key}) : super(key: key);

  @override
  _TeacherUploadMultimediaViewState createState() => _TeacherUploadMultimediaViewState();
}

class _TeacherUploadMultimediaViewState extends State<TeacherUploadMultimediaView> {

  List<Map<String,String>> _multimedia = [
    {
      "title":'Welcome',
      "type":"Video",
    },
    {
      "title":'Physics Notes',
      "type":"PDF",
    },
    {
      "title":'Chemistry Notes',
      "type":"PDF",
    },
    {
      "title":'Biology Notes',
      "type":"PDF",
    },
    {
      "title":'Notice 27-July-2021',
      "type":"PDF",
    },
    {
      "title":'Event photo',
      "type":"Image",
    },
    {
      "title":'Assignment-1',
      "type":"PDF",
    },
    {
      "title":'Assignment-2',
      "type":"PDF",
    },
    {
      "title":'Assignment-3',
      "type":"Video",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: semiBoldText('Multimedia',size: 16,color: Colors.white),
      ),
      body: Container(
        child: ListView(
          children: _multimedia.map((e) => Card(
            child: ListTile(
              title: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: boldText(e['title'],size: 18),
              ),
              subtitle: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        lightText('Added on',size: 14,color: Colors.grey),
                        const SizedBox(width: 8,),
                        regularText('24 July 2021',size: 14),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        lightText('Size',size: 14,color: Colors.grey),
                        const SizedBox(width: 8,),
                        regularText('2.1 Mb',size: 14),
                      ],
                    ),
                  ),
                ],
              ),
              trailing: _view(e),
            ),
          ),).toList(),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
          backgroundColor: Theme.of(context).primaryColor,
          onPressed: showCreateMedia,
          label: Row(
            children: [
              Icon(Icons.upload_outlined,color: Colors.white,),
              const SizedBox(width: 4,),
              semiBoldText('Upload Media',size: 12,color: Colors.white),
            ],
          ),
      ),
    );
  }

  _view(Map<String, String> e) {
    if(e['type']=='PDF')
      return SizedBox(
        width: 60,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Icon(Icons.picture_as_pdf,color: Colors.red,),
            Icon(Icons.cloud_download_outlined,color: primaryColor,)
          ],
        ),
      );
    else if(e['type']=='Image')
      return SizedBox(
        width: 60,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Icon(Icons.image,color: Colors.indigo,),
            Icon(Icons.cloud_download_outlined,color: primaryColor,)
          ],
        ),
      );
    else if(e['type']=='Video')
      return SizedBox(
        width: 60,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Icon(Icons.video_collection,color: Colors.purple,),
            Icon(Icons.cloud_download_outlined,color: primaryColor,)
          ],
        ),
      );
    else SizedBox();
  }

  void showCreateMedia(){
    showModalBottomSheet(
        context: context,
        builder: (_) => Padding(
          padding: MediaQuery.of(context).viewInsets,
          child: CreateMediaPopup(),
        ),
        isScrollControlled: true,
        isDismissible: true,
        backgroundColor: Colors.transparent,
    );
  }
}
