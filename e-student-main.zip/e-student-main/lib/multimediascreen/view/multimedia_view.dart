import 'package:e_student/homescreen/view/teacher_home_view.dart';
import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';

class MultimediaView extends StatefulWidget {
  final bool needButton;
  const MultimediaView({Key key,this.needButton=false}) : super(key: key);

  @override
  _MultimediaViewState createState() => _MultimediaViewState();
}

class _MultimediaViewState extends State<MultimediaView> {

  List<Map<String,String>> _multimedia = [
    {
      "title":'Welcome',
      "type":"Video",

    },
    {
      "title":'Physics Notes',
      "type":"PDF",
      "selected":"0",
    },
    {
      "title":'Chemistry Notes',
      "type":"PDF",
      "selected":"0",
    },
    {
      "title":'Biology Notes',
      "type":"PDF",
      "selected":"0",
    },
    {
      "title":'Notice 27-July-2021',
      "type":"PDF",
      "selected":"0",
    },
    {
      "title":'Event photo',
      "type":"Image",
      "selected":"0",
    },
    {
      "title":'Assignment-1',
      "type":"PDF",
      "selected":"0",
    },
    {
      "title":'Assignment-2',
      "type":"PDF",
      "selected":"0",
    },
    {
      "title":'Assignment-3',
      "type":"Video",
      "selected":"0",
    },
  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:  AppBar(
        title: semiBoldText('Multimedia',size: 16,color: Colors.white),
      ),
      body: Container(
        color: Colors.white,
        child: ListView(
          children: _multimedia.map((e) => Card(
            color: e['selected']=='1'?Colors.deepPurple.shade50:Colors.white,
            child: ListTile(
              onTap: (){
                setState(() {
                  e.update('selected', (value) =>value=="1"?"0":"1");
                });
              },
              selectedTileColor: primaryColor.withOpacity(0.1),
              title: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: boldText(e['title'],size: 18),
              ),
              subtitle: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        lightText('Added on',size: 14,color: Colors.grey),
                        const SizedBox(width: 8,),
                        regularText('24 July 2021',size: 14),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        lightText('Size',size: 14,color: Colors.grey),
                        const SizedBox(width: 8,),
                        regularText('2.1 Mb',size: 14),
                      ],
                    ),
                  ),
                ],
              ),
              trailing: _view(e),
            ),
          ),).toList(),
        ),
      ),
      bottomNavigationBar: widget.needButton?GestureDetector(
        onTap: (){
          Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_)=>TeacherHomeView()), (route) => false);
        },
        child: Container(
          height: 50,
          color: primaryDark,
          alignment: Alignment.center,
          child: semiBoldText('Assign',color: Colors.white,),
        ),
      ):SizedBox(height: 1,),
    );
  }

  _view(Map<String, String> e) {
    if(e['type']=='PDF')
      return SizedBox(
        width: 60,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Icon(Icons.picture_as_pdf,color: Colors.red,),
            Icon(Icons.cloud_download_outlined,color: primaryColor,)
          ],
        ),
      );
    else if(e['type']=='Image')
      return SizedBox(
        width: 60,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Icon(Icons.image,color: Colors.indigo,),
            Icon(Icons.cloud_download_outlined,color: primaryColor,)
          ],
        ),
      );
    else if(e['type']=='Video')
      return SizedBox(
        width: 60,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Icon(Icons.video_collection,color: Colors.purple,),
            Icon(Icons.cloud_download_outlined,color: primaryColor,)
          ],
        ),
      );
    else SizedBox();
  }
}
