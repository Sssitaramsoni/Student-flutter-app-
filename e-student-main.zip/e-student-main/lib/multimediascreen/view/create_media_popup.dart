import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/button.dart';
import 'package:e_student/view/custom_widget.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CreateMediaPopup extends StatefulWidget {
  const CreateMediaPopup({Key key}) : super(key: key);

  @override
  _CreateMediaPopupState createState() => _CreateMediaPopupState();
}

class _CreateMediaPopupState extends State<CreateMediaPopup> {

  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _desController = TextEditingController();
  final TextEditingController _dateController = TextEditingController();

  var file = false;
  var link = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      height: MediaQuery.of(context).size.height*0.60,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(10),
          topRight: Radius.circular(10),
        )
      ),
      child: Column(
        children: [
          ClosePopupWidget(),
          Expanded(
            child: ListView(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    AppCheckBox(value: file, onChanged: (val){
                      setState(() {
                        file = true;
                        link = false;
                      });
                    },label: 'File',),

                    AppCheckBox(value: link, onChanged: (val){
                      setState(() {
                        link = true;
                        file = false;
                      });
                    },label: 'Link',),
                  ],
                ),

                Container(
                  color: Colors.white,
                  padding: const EdgeInsets.all(10 ),
                  child: TextField(
                    controller: _titleController,
                    maxLines: 1,
                    minLines: 1,
                    style: GoogleFonts.lato(
                      fontSize: 14,
                      color: primaryColor,
                    ),
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.next,
                    decoration: InputDecoration(
                      hintText: 'Title *',
                      hintStyle:GoogleFonts.lato(
                        fontSize: 14,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 10,),

                Container(
                  color: Colors.white,
                  padding: const EdgeInsets.all(10 ),
                  child: TextField(
                    controller: _desController,
                    maxLines: 5,
                    minLines: 1,
                    style: GoogleFonts.lato(
                      fontSize: 14,
                      color: primaryColor,
                    ),
                    keyboardType: TextInputType.multiline,
                    textInputAction: TextInputAction.done,
                    decoration: InputDecoration(
                      hintText: 'Description *',
                      hintStyle:GoogleFonts.lato(
                        fontSize: 14,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 10,),

                Container(
                  color: Colors.white,
                  padding: const EdgeInsets.all(10 ),
                  child: TextField(
                    controller: _dateController,
                    maxLines: 1,
                    minLines: 1,
                    readOnly: true,
                    style: GoogleFonts.lato(
                      fontSize: 14,
                      color: primaryColor,
                    ),
                    keyboardType: TextInputType.datetime,
                    textInputAction: TextInputAction.done,
                    decoration: InputDecoration(
                      hintText: 'Date *',
                      hintStyle:GoogleFonts.lato(
                        fontSize: 14,
                        color: Colors.grey,
                      ),
                      suffixIcon: InkWell(
                        onTap:_datePicker,
                        child: Icon(Icons.calendar_today,color: primaryColor,),
                      )
                    ),
                  ),
                ),

                const SizedBox(height: 10,),

                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(width: 0.5),
                  ),
                  child: Row(
                    children: [
                      Expanded(child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('File name',style: GoogleFonts.lato(color: Colors.grey),),
                      )),
                      GestureDetector(
                        onTap: (){},
                        child: Container(
                          width: 100,
                          padding: const EdgeInsets.all(10),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: primaryColor,
                            borderRadius: BorderRadius.only(
                              topRight: Radius.circular(8),
                              bottomRight: Radius.circular(8),
                            )
                          ),
                          child: regularText('Select File',size: 12,color: Colors.white),
                        ),
                      )
                    ],
                  ),
                ),

                const SizedBox(height: 10,),

              ],
            ),
          ),
          SizedBox(width: MediaQuery.of(context).size.width,height: 40 ,child: button(text: 'Submit', onClick: (){
            Navigator.of(context).pop();
          })),
        ],
      ),
    );
  }

  void _datePicker()async{
    showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(Duration(days: 30)),
    ).then((value) =>value!=null? setState((){_dateController.text=value.toString();}):null);
  }
}
