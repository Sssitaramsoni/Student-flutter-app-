import 'grievance_history_view.dart';
import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/button.dart';
import 'package:e_student/view/custom_widget.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CreateGrievanceView extends StatefulWidget {
  @override
  _CreateGrievanceViewState createState() => _CreateGrievanceViewState();
}

class _CreateGrievanceViewState extends State<CreateGrievanceView> {

  final TextEditingController _applicationName = TextEditingController();
  final TextEditingController _comment = TextEditingController();

  var sanstha=false;
  var principle = false;
  var teacher = false;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: semiBoldText('Create Grievance',size: 16,color: Colors.white),
        actions: [
          IconButton(onPressed: (){
            Navigator.of(context).push(MaterialPageRoute(builder: (_)=>GrievanceHistoryView()));
          }, icon: Icon(Icons.history_outlined))
        ],
      ),
      body: Container(
        padding: const EdgeInsets.all(10),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 6),
                decoration: BoxDecoration(
                  color: primaryColor.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  children: [
                    boldText('Grievance URL for outsider:',color: primaryColor),
                    const SizedBox(height: 5,),
                    regularText('https://schoo/zilla.in/#/outside9rie11ancej22'),
                  ],
                ),
              ),

              const SizedBox(height: 10,),

              Container(
                color: Colors.white,
                padding: const EdgeInsets.all(10 ),
                child: TextField(
                  controller: _applicationName,
                  maxLines: 1,
                  minLines: 1,
                  style: GoogleFonts.lato(
                    fontSize: 14,
                    color: primaryColor,
                  ),
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    hintText: 'Application Name *',
                    hintStyle:GoogleFonts.lato(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 10,),

              Container(
                color: Colors.white,
                padding: const EdgeInsets.all(14),
                child: Wrap(
                  spacing: 14,
                  runSpacing: 14,
                  children: [
                    AppCheckBox(value: sanstha, onChanged: (val){
                      setState(() {
                        sanstha = true;
                        principle = false;
                        teacher = false;
                      });
                    },label: 'To Sanstha',),

                    AppCheckBox(value: principle, onChanged: (val){
                      setState(() {
                        sanstha = false;
                        principle = true;
                        teacher = false;
                      });
                    },label: 'To Principle',),

                    AppCheckBox(value: teacher, onChanged: (val){
                      setState(() {
                        sanstha = false;
                        principle = false;
                        teacher = true;
                      });
                    },label: 'To Teacher',),

                  ],
                ),
              ),

              const SizedBox(height: 10,),

              Container(
                decoration: BoxDecoration(
                  color: primaryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.only(left: 10,right: 10,bottom: 10),
                child: TextField(
                  controller: _comment,
                  maxLines: 10,
                  maxLength: 400,
                  style: GoogleFonts.lato(
                    color: primaryColor,
                    fontSize: 16,
                  ),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: 'Type here...',
                    hintStyle: GoogleFonts.lato(
                      color: Colors.grey,
                      fontSize: 14,
                    )
                  ),
                ),
              ),

              const SizedBox(height: 10,),

              button(text: 'Submit', onClick: (){},color: Colors.green),

            ],
          ),
        ),
      ),
    );
  }
}
