import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';

class GrievanceHistoryView extends StatefulWidget {
  const GrievanceHistoryView({Key key}) : super(key: key);

  @override
  _GrievanceHistoryViewState createState() => _GrievanceHistoryViewState();
}

class _GrievanceHistoryViewState extends State<GrievanceHistoryView> {

  List<int> _list = [1,2,3,4,5,6,7,08,10,15,18];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:  AppBar(
        title: semiBoldText('Grievance History',size: 16,color: Colors.white),
        actions: [
          IconButton(onPressed: (){
            setState(() {
              _list.sort((a,b)=>b.compareTo(a));
            });
          }, icon: Icon(Icons.sort))
        ],
      ),
      body: Container(
        child: ListView(
        children: _list.map((e) => Card(
          child: ListTile(
            title: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: boldText('Application Name',size: 18),
            ),
            subtitle: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      lightText('Date',size: 14,color: Colors.grey),
                      const SizedBox(width: 8,),
                      regularText('$e July 2021',size: 14),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),).toList(),
        ),
      ),
    );
  }
}
