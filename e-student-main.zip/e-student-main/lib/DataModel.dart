import 'dart:convert';

DataModel dataModelFromJson(String str) => DataModel.fromJson(json.decode(str));

String dataModelTojson(DataModel data) => json.encode(data.toJson());

class DataModel {
  DataModel({
    this.userName,
    this.userPassword,
    
  });

  String userName;
  String userPassword;
  

  factory DataModel.fromJson(Map<String, dynamic> json) => DataModel(
        userName: json["userName"],
        userPassword: json["userPassword"],
        
      );

  Map<String, dynamic> toJson() => {
    "userName": userName,
    "userPassword": userPassword,
    

  };
}
