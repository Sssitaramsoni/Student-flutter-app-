import 'package:flutter/material.dart';


const Color primaryColor = Color(0xff0C4160);
const Color primaryDark = Color(0xff07273a);

const MaterialColor materialColor = MaterialColor(0xff0C4160, {
  50: const Color.fromRGBO(12, 65, 96, 0.01),
  100: const Color.fromRGBO(12, 65, 96, 0.2),
  200: const Color.fromRGBO(12, 65, 96, 0.3),
  300: const Color.fromRGBO(12, 65, 96, 0.4),
  400: const Color.fromRGBO(12, 65, 96, 0.5),
  500: primaryColor,
  600: const Color.fromRGBO(12, 65, 96, 0.7),
  700: const Color.fromRGBO(12, 65, 96, 0.8),
  800: const Color.fromRGBO(12, 65, 96, 0.9),
  900: const Color.fromRGBO(12, 65, 96, 1.0),
});
