
class DataUtil{

  DataUtil._();

  static DataUtil _instance = DataUtil._();

  static DataUtil get instance => _instance;


}