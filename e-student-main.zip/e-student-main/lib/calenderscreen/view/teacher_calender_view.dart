import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/button.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_calendar_carousel/classes/event.dart';
import 'package:flutter_calendar_carousel/flutter_calendar_carousel.dart';
import 'package:google_fonts/google_fonts.dart';

class TeacherCalenderView extends StatefulWidget {
  const TeacherCalenderView({Key key}) : super(key: key);

  @override
  _TeacherCalenderViewState createState() => _TeacherCalenderViewState();
}

class _TeacherCalenderViewState extends State<TeacherCalenderView> {

  DateTime _currentDate = DateTime.now();

  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _startTime = TextEditingController();
  final TextEditingController _endTime = TextEditingController();
  final TextEditingController _password = TextEditingController();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: semiBoldText('Event & Holiday',size: 16,color: Colors.white),
      ),
      body: Container(
        child: Column(
          children: [
            Container(
              color: Colors.white,
              padding: const EdgeInsets.all(10 ),
              child: TextField(
                controller: _titleController,
                maxLines: 1,
                minLines: 1,
                style: GoogleFonts.lato(
                  fontSize: 14,
                  color: primaryColor,
                ),
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.next,
                decoration: InputDecoration(
                  hintText: 'Title *',
                  hintStyle:GoogleFonts.lato(
                    fontSize: 14,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),
            Container(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        color: Colors.white,
                        padding: const EdgeInsets.all(10 ),
                        child: TextField(
                          controller: _startTime,
                          maxLines: 1,
                          minLines: 1,
                          readOnly: true,
                          style: GoogleFonts.lato(
                            fontSize: 14,
                            color: primaryColor,
                          ),
                          keyboardType: TextInputType.text,
                          textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                              hintText: 'Start time *',
                              hintStyle:GoogleFonts.lato(
                                fontSize: 14,
                                color: Colors.grey,
                              ),
                              suffixIcon: InkWell(
                                onTap:()=>_timePicker(1),
                                child: Icon(Icons.watch_later_outlined,color: primaryColor,),
                              )
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10,),
                    Expanded(
                      child: Container(
                        color: Colors.white,
                        padding: const EdgeInsets.all(10 ),
                        child: TextField(
                          controller: _endTime,
                          maxLines: 1,
                          minLines: 1,
                          readOnly: true,
                          style: GoogleFonts.lato(
                            fontSize: 14,
                            color: primaryColor,
                          ),
                          keyboardType: TextInputType.text,
                          textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                              hintText: 'End time *',
                              hintStyle:GoogleFonts.lato(
                                fontSize: 14,
                                color: Colors.grey,
                              ),
                              suffixIcon: InkWell(
                                onTap:()=>_timePicker(2),
                                child: Icon(Icons.watch_later_outlined,color: primaryColor,),
                              )
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                button(text: 'Submit', onClick: (){}),
                const SizedBox(width: 20,),
                button(text: 'Cancel', onClick: (){},color: Colors.red),
              ],
            ),
            const SizedBox(height: 20,),
            Expanded(
              flex: 2,
              child: CalendarCarousel<Event>(
                pageScrollPhysics: NeverScrollableScrollPhysics(),
                showOnlyCurrentMonthDate: true,
                onDayPressed: (DateTime date, List<Event> events) {
                  this.setState(() {
                    _currentDate = date;
                  });

                },
                weekendTextStyle: GoogleFonts.lato(
                  color: Colors.red,
                  fontWeight: FontWeight.bold,
                ),
                thisMonthDayBorderColor: Colors.grey,
                daysTextStyle: GoogleFonts.lato(
                  color: Theme.of(context).primaryColor,
                  fontWeight: FontWeight.bold,
                ),
                selectedDayBorderColor: Theme.of(context).primaryColor,
                selectedDayButtonColor: Theme.of(context).primaryColor,
                selectedDayTextStyle: GoogleFonts.lato(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
                weekdayTextStyle: GoogleFonts.lato(
                  color: Theme.of(context).primaryColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
                headerTextStyle: GoogleFonts.lato(
                  color: Theme.of(context).primaryColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 22,
                ),
                iconColor: Theme.of(context).primaryColor,
//      weekDays: null, /// for pass null when you do not want to render weekDays
//      headerText: Container( /// Example for rendering custom header
//        child: Text('Custom Header'),
//      ),
                customDayBuilder: (   /// you can provide your own build function to make custom day containers
                    bool isSelectable,
                    int index,
                    bool isSelectedDay,
                    bool isToday,
                    bool isPrevMonthDay,
                    TextStyle textStyle,
                    bool isNextMonthDay,
                    bool isThisMonthDay,
                    DateTime day,
                    ) {
                  /// If you return null, [CalendarCarousel] will build container for current [day] with default function.
                  /// This way you can build custom containers for specific days only, leaving rest as default.

                  if(day.weekday==7){
                    return Center(
                      child: Icon(Icons.fastfood,color: primaryDark,size: 16,),
                    );
                  }

                  // Example: every 15th of month, we have a flight, we can place an icon in the container like that:
                  // if (day.day == 15) {
                  //   return Center(
                  //     child: Icon(Icons.local_airport),
                  //   );
                  // } else {
                  //   return null;
                  // }

                  // return Container(
                  //   width: MediaQuery.of(context).size.width/7,
                  //   height: MediaQuery.of(context).size.height/7,
                  //   child: Text(day.day.toString()),
                  // );

                  return null;
                },
                weekFormat: false,
                selectedDateTime: _currentDate,
                childAspectRatio: 0.9,
                showHeader: false,
                daysHaveCircularBorder: false, /// null for not rendering any border, true for circular border, false for rectangular border
              ),
            ),
          ],
        ),
      ),
    );
  }

  _timePicker(int i) {
    showTimePicker(
        context: context,
        builder: (context, child) {
          return Theme(data: ThemeData.light().copyWith(
              primaryColor: primaryColor,
              colorScheme: ColorScheme.light(primary: primaryColor)
          ), child: child);
        },
        initialTime: TimeOfDay.now()).then((value){
      if(value!=null){
        setState(() {
          if(i==1)
            _startTime.text=value.format(context);
          else
            _endTime.text = value.format(context);
        });
      }
    },
    );
  }
}
