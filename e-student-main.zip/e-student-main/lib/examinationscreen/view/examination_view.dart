import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';

class ExaminationView extends StatefulWidget {
  @override
  _ExaminationViewState createState() => _ExaminationViewState();
}

class _ExaminationViewState extends State<ExaminationView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: semiBoldText('Examination',size: 16,color: Colors.white),
        actions: [
          popupMenu(),
        ],
      ),
      body: Container(
        child: ListView(
          children: [0,1,2,1,2,0,1,0,2].map((e) => Card(
            child: ListTile(
              title: boldText('Name',size: 18),
              subtitle: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        regularText('Duration',size: 14,color: Colors.grey),
                        const SizedBox(width: 8,),
                        regularText('2Hr 30min',size: 14),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        regularText('Code',size: 14,color: Colors.grey),
                        const SizedBox(width: 8,),
                        regularText('#Math001',size: 14),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        regularText('Start Time',size: 14,color: Colors.grey),
                        const SizedBox(width: 8,),
                        regularText('20 Aug 2021, 12:00 PM',size: 14),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        regularText('End Time',size: 14,color: Colors.grey),
                        const SizedBox(width: 8,),
                        regularText('20 Aug 2021, 02:30 PM',size: 14),
                      ],
                    ),
                  )
                ],
              ),
              trailing: _status(e),
            ),
          )).toList(),
        ),
      ),
    );
  }
  Widget _status(e){
    if(e==0)
      return semiBoldText('Incomplete',size: 12,color: Colors.deepOrange);
    if(e==1)
      return semiBoldText('In 2 days',size: 12,color: Colors.green);
    if(e==2)
      return semiBoldText('Completed',size: 12,color: Colors.green);
  }

  Widget popupMenu(){
   return PopupMenuButton(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Icon(Icons.sort),
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        onSelected: (index){},
       padding: const EdgeInsets.symmetric(horizontal: 10),
        itemBuilder: (context) => [
          PopupMenuItem(
            child: Text("By Date"),
            value: 1,
          ),
          PopupMenuItem(
            child: Text("By Name"),
            value: 2,
          )
        ]
    );
  }
}
