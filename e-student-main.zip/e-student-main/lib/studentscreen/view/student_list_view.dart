import 'package:e_student/homeworscreen/view/assign_home_work_view.dart';
import 'package:e_student/model/Dummy.dart';
import 'package:e_student/multimediascreen/view/multimedia_view.dart';
import 'package:e_student/util/color_util.dart';
import 'package:e_student/util/enum_util.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';

class StudentListView extends StatefulWidget {
  final ComingFrom comingFrom;
  const StudentListView({Key key,this.comingFrom = ComingFrom.ASSIGN_HOME_WORK}) : super(key: key);

  @override
  _StudentListViewState createState() => _StudentListViewState();
}

class _StudentListViewState extends State<StudentListView> {

  List<Dummy> _student = List.generate(20, (index) => Dummy(
    id: index,
    selected: false,
    name: '${String.fromCharCode(65+index)} $index',
    surname: 'Gupta',
    course: '987456321$index',
  ));

  void _check(){
    _student.forEach((element) {
      element.selected = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: semiBoldText('Student',size: 16,color: Colors.white),
        actions: [
          IconButton(onPressed: (){
            setState(() {
              _check();
            });
          }, icon: Icon(Icons.playlist_add_check,color: Colors.white,))
        ],
      ),
      body: Container(
        child: ListView.separated(
          itemBuilder: (_, index) => ListTile(
            onTap: (){
              setState(() {
                _student[index].selected = !_student[index].selected;
              });
            },
            selected: _student[index].selected,
            selectedTileColor: primaryColor.withOpacity(0.1),
            title: boldText('${_student[index].name} ${_student[index].surname}'),
            subtitle: regularText('${_student[index].course}'),
            leading: CircleAvatar(
              child: boldText(_student[index].name[0],color: Colors.white),
            ),
          ),
          separatorBuilder: (_, index) => Divider(),
          itemCount: _student.length,
        ),
      ),
      bottomNavigationBar:_student.any((element) => element.selected)? GestureDetector(
        onTap: (){
          if(widget.comingFrom == ComingFrom.ASSIGN_HOME_WORK)
          Navigator.of(context).push(MaterialPageRoute(builder: (_)=>AssignHomeWorkView()));
          else
            Navigator.of(context).push(MaterialPageRoute(builder: (_)=>MultimediaView(needButton: true,)));
        },
        child: Container(
          height: 50,
          color: primaryDark,
          alignment: Alignment.center,
          child: semiBoldText('Continue',color: Colors.white,),
        ),
      ):SizedBox(height: 1,),
    );
  }
}
