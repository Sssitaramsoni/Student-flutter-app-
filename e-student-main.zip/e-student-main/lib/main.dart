import 'package:e_student/homescreen/view/home_view.dart';
import 'package:e_student/splashscreen/splash_view.dart';
import 'package:e_student/util/color_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await _initAndRun();
  runApp(MyApp());
}

///
Future<void> _initAndRun()async{

}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.light,
      title: 'E-Student',
      theme: ThemeData.light().copyWith(
        primaryColorDark: primaryColor,
        primaryColor: primaryColor,
        accentColor: primaryColor,
        canvasColor: Colors.white,
        colorScheme:  ColorScheme.light(primary: primaryColor),
        appBarTheme: AppBarTheme(
          color: primaryColor,
          centerTitle: true,
          titleTextStyle: GoogleFonts.lato(color: Colors.white,fontSize: 18)
        ),
      ),
      home: SplashView(),
    );
  }
}
