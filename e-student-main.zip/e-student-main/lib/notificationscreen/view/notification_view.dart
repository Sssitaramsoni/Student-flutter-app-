import 'package:e_student/view/text.dart';
import 'package:flutter/material.dart';

class NotificationView extends StatefulWidget {

  const NotificationView({Key key}) : super(key: key);

  @override
  _NotificationViewState createState() => _NotificationViewState();
}

class _NotificationViewState extends State<NotificationView> {
  
  List<int> _notifications = [1,2,3,1,1,11,1,1,1,1,1,1,1,1,1,1];
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:  AppBar(
        title: semiBoldText('Notification',size: 16,color: Colors.white),
      ),
      body: Container(
        child: ListView.separated(
          itemCount: _notifications.length,
          itemBuilder: (_,i)=>ListTile(
            leading: CircleAvatar(
              child: boldText('S',color: Colors.white),
            ),
            title: Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: boldText('Title'),
            ),
            subtitle: lightText('In order to customize your buttons inside GroupButton you can use code below'),
          ),
          separatorBuilder: (_,i)=>Container(
            margin: const EdgeInsets.only(left: 65,top: 6),
            color: Colors.indigo.shade50,
            height: 1,
          ),
        ),
      ),
    );
  }
}
