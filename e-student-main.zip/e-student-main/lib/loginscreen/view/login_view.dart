import 'package:e_student/ApiService.dart';

import 'package:e_student/homescreen/view/home_view.dart';
import 'package:e_student/homescreen/view/teacher_home_view.dart';
import 'package:e_student/util/color_util.dart';
import 'package:e_student/view/button.dart';
import 'package:e_student/view/text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginView extends StatefulWidget {
  const LoginView({Key key}) : super(key: key);

  @override
  _LoginViewState createState() => _LoginViewState();
}

// Future<DataModel> submitData(
//     String userName, String userPassword,   ) async {
//   var response = await http.post(Uri.parse("https://schoolzillaserver.schoolzilla.in/login"),
//   //  headers: <String, String>{
//   //     'Content-Type': 'application/json; charset=UTF-8',
//   //   },
//       body: {
// "userName": userName,
// "userPassword": userPassword
// });
//  var data = response.body;
//   print(data);
//   if (response.statusCode == 200) {
//     String responseString = response.body;
//     dataModelFromJson(responseString);
//   } else
//     return null;
// }

final userName = TextEditingController();
final userPassword = TextEditingController();

var loginApiResponse;
Future callLoginApi() async {
  final service = ApiServices();

  loginApiResponse = await service.apiCallLogin(
    {
      "userName": userName.text,
      "userPassword": userPassword.text,
    },
  );
  print("==============================");
  print(loginApiResponse['instituteId']);
  print(loginApiResponse['token']);
  print(loginApiResponse['academicYearId']);
  print(loginApiResponse['roles']['student']);
 
  SharedPreferences prefs = await SharedPreferences.getInstance();
  
  
  await prefs.setString('token', '${loginApiResponse['token']}'.toString());
  await prefs.setString('instituteId','${loginApiResponse['instituteId']}'.toString());
  
  // if (loginApiResponse.error != null) {
  //   print("get data >>>>>> " + loginApiResponse.error);
  // } else {
  //   print(loginApiResponse.token);
  // }  academicYearId  9657589090

  // return loginApiResponse;
}

class _LoginViewState extends State<LoginView> {
  //  DataModel _dataModel;
  //  TextEditingController userNameController = TextEditingController();
  //  TextEditingController userPasswordController = TextEditingController();

  var secure = true;
  var teacher = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(
              height: 50,
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
              child: boldText(
                'Welcome,',
                size: 18,
                color: primaryColor,
              ),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
              child: regularText('Enter detail for login', color: primaryColor),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              decoration: BoxDecoration(
                  color: Colors.indigo.shade50,
                  borderRadius: BorderRadius.circular(8)),
              child: TextField(
                controller: userName,
                style: GoogleFonts.lato(
                  color: primaryColor,
                ),
                decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: 'Username',
                    hintStyle: GoogleFonts.lato()),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              decoration: BoxDecoration(
                  color: Colors.indigo.shade50,
                  borderRadius: BorderRadius.circular(8)),
              child: TextField(
                controller: userPassword,
                obscureText: secure,
                style: GoogleFonts.lato(
                  color: primaryColor,
                ),
                decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: 'Password',
                    hintStyle: GoogleFonts.lato(),
                    suffixIcon: InkWell(
                      onTap: () {
                        setState(() {
                          secure = !secure;
                        });
                      },
                      child: Icon(
                          secure ? Icons.visibility_off : Icons.visibility),
                    )),
              ),
            ),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: lightText('Make sure you enter your details correctly.'),
            ),
            SizedBox(
                width: 120,
                height: 40,
                child: button(
                    text: 'Login',
                    onClick: () async {
                      if (userName.text.isNotEmpty &&
                          userPassword.text.isNotEmpty) {
                        int statusCode = await callLoginApi();

                        if (loginApiResponse['roles']['student'] == true) {
                          if (teacher)
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (_) => TeacherHomeView()));
                          else
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => HomeView(
                                      instituteId:
                                          loginApiResponse['instituteId'].toString(),
                                    )));
                        } else {
                          print(statusCode);
                          // dialogBox('Incorrect Credentials');
                        }
                      }

                      //  String userName = userNameController.text;
                      //       String userPassword = userPasswordController.text;

                      //       DataModel data =
                      //           await submitData(userName,  userPassword,);

                      //       setState(() {
                      //         _dataModel = data;
                      //       });
                    })),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
              child: TextButton(
                style: TextButton.styleFrom(
                    textStyle: GoogleFonts.lato(
                        fontSize: 16, fontWeight: FontWeight.bold)),
                onPressed: () {
                  setState(() {
                    teacher = !teacher;
                  });
                },
                child: Text(teacher ? 'Student Login' : 'Teacher Login'),
              ),
            ),
            Spacer(),
            Image.asset(
              'assets/images/login.jpg',
              height: 200,
            )
          ],
        ),
      ),
    );
  }

  dialogBox(String dialog) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => CupertinoAlertDialog(
              title: Center(
                child: Text(dialog),
              ),
              actions: [
                CupertinoButton(
                    child: Text('ok'),
                    onPressed: () {
                      Navigator.of(context, rootNavigator: true).pop('dialog');
                    })
              ],
            ));
  }
}
